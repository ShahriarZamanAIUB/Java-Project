import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 import java.io.File; 
 import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.*; 
import javax.swing.JScrollPane;
 import javax.swing.JFrame; 
import javax.swing.JTable; 
import javax.swing.table.*;
 


 
 class showCourses extends JFrame implements ActionListener
 {  JButton b1,b2,b3,b4,lx,bx; 
  JTextField t1,t2;
   JLabel l1,l2,l3;
	  JPanel p1,p2;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
	  JTable tb1;
	  JScrollPane jscp;
	  String name,id,password,roll;
	  
	  String[] colm={"Subject","Sunday","Monday","Tuesday","Wednesday",};
	   
	  String[][] row={   
		                      
		  
		  
		  {"Programming-1",   "13", "27", "10", "20" },
		   {"Math-1","10",    "40", "10", "20", "30" },
		    {"Physics-1",     "10", "40", "10", "20" },
			 {"ICS","7",      "10", "10", "20", "30" },
			  {"English-1",   "10", "20", "13", "20"  },
				 
		  
		   
		  
	  };
		 
	
	public static String cut(String s, int x, int y)
	{
		
		 String ss=s.substring(x-1,y);
		 int xx=Integer.parseInt(ss);
		 
		 return String.valueOf(xx);
		
		
	}
	
	public static String cutCalcGrade(String s)
	{
		 String ss=new String(s.substring(1,3));  
		 int x1=Integer.parseInt(ss);  
		 
		  String ss2=new String(s.substring(5,7));
		 int x2=Integer.parseInt(ss2);  
		 
		 String ss3=new String(s.substring(9,11));
		 int x3=Integer.parseInt(ss3); 
		 
		  String ss4=new String(s.substring(13,15));
		 int x4=Integer.parseInt(ss4);  
		 
		 String ss5=new String(s.substring(17,19));
		 int x5=Integer.parseInt(ss5);  
		 
		 int sum=x1+x2+x3+x4+x5;    
		 
		 if(sum<=100 && sum>=90) {return "A+";}
		 
		 else if(sum<90 && sum>=85) {return "A";}
		 
		  else if(sum<85 && sum>=80) {return "B+";}
		  
		   else if(sum<80 && sum>=75) {return "B";}
		   
		    else if(sum<75 && sum>=70) {return "C+";}
			 else if(sum<70 && sum>=65) {return "C";}
			 
			  else if(sum<65 && sum>=60) {return "D+";}
			  
			  else if(sum<60 && sum>=50) {return "D";}
			  
			   else if(sum<50 && sum>=0) {return "F";}
			   
			   return "0";
		
		
		
	}
	
	
	public static double cutCalcGradePoint(String s)
	{
		 String ss=new String(s.substring(1,3));  
		 int x1=Integer.parseInt(ss);  
		 
		  String ss2=new String(s.substring(5,7));
		 int x2=Integer.parseInt(ss2);  
		 
		 String ss3=new String(s.substring(9,11));
		 int x3=Integer.parseInt(ss3); 
		 
		  String ss4=new String(s.substring(13,15));
		 int x4=Integer.parseInt(ss4);  
		 
		 String ss5=new String(s.substring(17,19));
		 int x5=Integer.parseInt(ss5);  
		 
		 int sum=x1+x2+x3+x4+x5;    
		 
		 if(sum<=100 && sum>=90) {return 4.0;}
		 
		 else if(sum<90 && sum>=85) {return 3.75;}
		 
		  else if(sum<85 && sum>=80) {return 3.5;}
		  
		   else if(sum<80 && sum>=75) {return 3.25;}
		   
		    else if(sum<75 && sum>=70) {return 3.0;}
			 else if(sum<70 && sum>=65) {return 2.75;}
			 
			  else if(sum<65 && sum>=60) {return 2.5;} 
			  
			  else if(sum<60 && sum>=50) {return 2.25;}
			  
			   else if(sum<50 && sum>=0) {return 0.0;}
			   
			   return 0.0;
		
		
		
	}
	
	public void cyan(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.cyan);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 
	
	
		public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 	 
	
	 showCourses()
	{    super("Courses and Routine");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,60);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   setResizable(false);
	   setLocationRelativeTo(null);
	   
	   
	    heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,0));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("Your Courses");
		 header.setBounds( 530,3,900,80);
		header.setFont(f);
		header.setForeground(Color.yellow);
		//heading.add(header);
		
		
		 
		 
		
		 ImageIcon background_image=new ImageIcon("page3.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		
		 
		 
		 
		 
		  
	    
		try{   File myFile=new File("slogininfo.txt");
					   Scanner m=new Scanner(myFile);
					   while(m.hasNextLine())
					   {  roll=m.nextLine();
				          
				        name=m.nextLine();
				        id=m.nextLine();
						 password=m.nextLine();
				        
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       } 
		
		
		int i=0,j=0;
		
		
					 String course1=new String();
					 String course2=new String();
			         String course3=new String();
					 String course4=new String();
					 String course5=new String();
					 
					 String marksArray1=new String();
					 String marksArray2=new String();
					 String marksArray3=new String();
					 String marksArray4=new String();
					 String marksArray5=new String();
					 
		 
			 
			 
			 
			
			       String aa[]=new String[100];
				   String bb[]=new String[100];
				   String cc[]=new String[100];
				   String dd[]=new String[100];
				   String ee[]=new String[100];
				   String ff[]=new String[100];
				   String gg[]=new String[100];
				   String hh[]=new String[100];
				   String ii[]=new String[100];
				   String jj[]=new String[100];
				   String kk[]=new String[100];
				   String ll[]=new String[100];
				   String mm[]=new String[100];
				  
			
			
			
			try{   File myFile=new File("allstudentsinfo3.txt");
					   Scanner m=new Scanner(myFile);
					   while(m.hasNextLine())
					   {  aa[i]=m.nextLine(); 
				          bb[i]=m.nextLine(); 
                          cc[i]=m.nextLine();
						  dd[i]=m.nextLine();  
						  ee[i]=m.nextLine();
						  ff[i]=m.nextLine();
                          gg[i]=m.nextLine();
                          hh[i]=m.nextLine();
                          ii[i]=m.nextLine();
                          jj[i]=m.nextLine();
                          kk[i]=m.nextLine();
                          ll[i]=m.nextLine();
                          mm[i]=m.nextLine();						  
				     
						   i++;
						   
						   
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }  
									   
									   
				for(j=0; j<=i && aa[j]!=null && mm[j]!=null; j++)	
                {
					if(bb[j].equals(name))
					{
						 
						
						course1=dd[j];  
						marksArray1=ee[j];
						course2=ff[j];
						marksArray2=gg[j];
						course3=hh[j];
						marksArray3=ii[j];
						course4=jj[j];
						marksArray4=kk[j];
						course5=ll[j];
						marksArray5=mm[j];
						
						 
						
					}
					else{continue; }
					
					
					j++;
					
					
				}					
		 
	 
		  
		
		String ea="8:00am to 9:30am";
		 String pa="11:00am to 2:00pm";
		  String ma="2:00 pm to 3:30pm";
		   String pha="8:00 pm to 11:00am";
		   String ic="11:30 pm to 2:00pm";
		   String pbc="12:30pm to 2:00 pm";
		   String phb="2:00 pm to 3:30pm";
		   String vv="";
		 
		 
		
		 String[][] row2={   
		 
		 
		 {course1,  pa,  pbc, vv, pbc},
		 {course2,  ma,  vv,  ma, vv},
		 {course3,  pha, phb, vv, phb},
		 {course4,  vv,  vv,  pbc, vv},
		 {course5,  ea,  vv,  ea, vv},
		 
		                      
		  
		  
		  
				 
		  
		   
		  
	  };   row=row2;
		
		
	 
		
		
		  p1=new JPanel();
		// p1.setSize(600,500);
		 p1.setBounds(0,120,1700,800);
		  p1.setBackground(new Color(0,0,0,60));
		p1.setLayout(null);
		 
		 bx=new JButton("Credits : 15");
		bx.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		bx.setForeground(Color.black);
		bx.setBounds(580,420,300,50);
		bx.setBackground(Color.white);
		//cyan(lx);
		p1.add(bx);
		 	 
		
		l3=new JLabel(name+" :");
		l3.setFont(new Font("Comic Sans MS",Font.BOLD,35));
		l3.setForeground(Color.yellow);
		l3.setBounds(580,27,1000,50);
		 
		//cyan(lx);
		p1.add(l3);
 
		 
		 tb1=new JTable(row,colm);
		 tb1.setFont(f2);
		 tb1.getTableHeader().setFont(f2);
		 tb1.setEnabled(false);
		 tb1.setSelectionBackground(Color.green);
		 tb1.setRowHeight(50);
		  
	 	  
tb1.getColumnModel().getColumn(0).setPreferredWidth(300);
tb1.getColumnModel().getColumn(1).setPreferredWidth(300);
tb1.getColumnModel().getColumn(2).setPreferredWidth(300);
tb1.getColumnModel().getColumn(3).setPreferredWidth(300);
tb1.getColumnModel().getColumn(4).setPreferredWidth(300);
 
		  
		  
		 /* DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(5).setCellRenderer(centerRenderer); 

		 DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
centerRenderer2.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(6).setCellRenderer(centerRenderer2); */

 

		    jscp= new JScrollPane(tb1);
			jscp.setBounds(20,80,1500,310);
			jscp.setFont(f2);
			  jscp.setPreferredSize(new Dimension(1000, 700));
			p1.add(jscp);
		 
		 
		 
		   b4=new JButton("Back");
		  b4.setBounds(580,600,300,50);
		  b4.setFont(f2);
		  //b3.setVisible(false);
		  b4.addActionListener(this);
		  
	 
         ylw(b4);


		  p1.add(b4);
		
		
		
		
		 
		 
		 
		 
	 
		
		this.add(p1);
		
		 
		 
		  background.add(header);
		 add(background);
		setVisible(true);
	}
	
	
	 public void actionPerformed(ActionEvent ae)
		{   
		
	 if(ae.getSource()==b4 )
			{   b4.setBackground(Color.yellow);
		       
		     //   b2.setBackground(Color.white);
			//	b1.setBackground(Color.white);
				
				 		
				
				 
			sMenu fx=new sMenu();
			 this.setVisible(false);
				 fx.setVisible(true);
			
		} }
	
	public static void main(String[] args)
 {
	showCourses pq=new showCourses();
	 
	 
	 
 }
 
 }
	