import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files


public class start
{

public static void main(String[] args)
 {
	 
	 String x=new String();
	 sMenu s;
	 aMenu a;  
	 tMenu t;
	 page1 p;
	 
	 try{
      File myObj = new File("loginstatus.txt");
	  Scanner m=new Scanner(myObj);
	  
	  while(m.hasNextLine())
	  { x=m.nextLine();} m.close();
	  
	  if(x.equals("1")){ s=new sMenu();}
	  
	   else if(x.equals("2")){ t=new tMenu();}
	  
	  else if(x.equals("3")){ a=new aMenu();}
	  
	   else if(x.equals("0")){ p=new page1();}
	 
 }
catch (FileNotFoundException e) {
      System.out.println("An error occurred. Your file was not found.");
      e.printStackTrace();
    }



}}