 import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
import java.util.Scanner;
import java.io.*; 


 
 class addStudent extends JFrame implements ActionListener
 {  
  JButton b1,b2,b3; 
  JTextField t1,t2,t3;
   JLabel l1,l2,l3;
	  JPanel p1,p2;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
		 
		 
			public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 	 
		 
		 
	
	 addStudent()
	{  super("Student Registration");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,50);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,70));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("Student Registration");
		 header.setBounds( 500,3,600,80);
		header.setFont(f);
		header.setForeground(Color.green);
		//heading.add(header);
		
		 
		
		 ImageIcon background_image=new ImageIcon("page6.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		 
		 //
		 
	      p1=new JPanel();
	     p1.setSize(800,500);
		 p1.setBounds(250,200,1000,800);
		 p1.setBackground(new Color(0,0,0,30));
		 p1.setLayout(null);
		 
		  p2=new JPanel();
		// p1.setSize(600,500);
		 p2.setBounds(400,200,700,600);
		  p2.setBackground(new Color(0,0,0,0));
		 p2.setLayout(null);
		 
		  l1 = new JLabel("Enter His/Her Name:");
		l1.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l1.setForeground(Color.yellow);
		l1.setBounds(50,120,1000,50);
		p1.add(l1);
		
		 
		 t1=new JTextField( );
		 t1.setFont(f2);
		 t1.setBounds(370,120,450,50);
	     t1.addActionListener(this);
		 p1.add(t1);
		 
		 l2 = new JLabel("Enter His/Her ID:");
		l2.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l2.setForeground(Color.yellow);
		l2.setBounds(50,190,1000,50);
		p1.add(l2);
		
		
		l3 = new JLabel("Enter His/Her Password:");
		l3.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l3.setForeground(Color.yellow);
		l3.setBounds(50,260,1000,50);
		p1.add(l3);
		 
		  t2=new JTextField( );
		  t2.setFont(f2);
		  t2.setBounds(370,190,450,50);
	      t2.addActionListener(this);
		  p1.add(t2);
		  
		  
		  t3=new JTextField( );
		  t3.setFont(f2);
		  t3.setBounds(370,260,450,50);
	      t3.addActionListener(this);
		  p1.add(t3);
		 
		 
		 
		 b1=new JButton("Register");
		 b1.setBounds(280,350,400,50);
		  b1.setFont(f2);
		  b1.setForeground(Color.green);
		  b1.addActionListener(this);
		  
		   ylw(b1);
		  
		 p1.add(b1);
		 
		 l3 = new JLabel( );
		l3.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l3.setForeground(Color.white);
		l3.setBounds(200,400,250,50);
		p1.add(l3);
		
	 
		  
		  
		   b2=new JButton("Back");
		  b2.setBounds(170,410,300,50);
		  b2.setFont(f2);
		   
		  b2.addActionListener(this);
		  
		      ylw(b2);
		  p2.add(b2);
		 
		 
		 
	 
		//  
		 
		 
		 
	 
		
	 
		
		  this.add(p1);
		  this.add(p2);
		  background.add(header);
		 add(background);
		 
		setVisible(true);
		
		  if(t1.getText()==null || t2.getText()==null || t3.getText()==null)
			 {b1.setText("Texfields Are Empty!!!"); }
		 
	}
 
 
      void Delay(Long ms){

       Long dietime = System.currentTimeMillis()+ms;
       while(System.currentTimeMillis()<dietime){
           //do nothing
       }
   }

 
 
 public void actionPerformed(ActionEvent ae)
		{     
		    
				   
			
			if(ae.getSource()==b1)
			{ 
				

            if(t1.getText().isEmpty()==true || t2.getText().isEmpty()==true  || t3.getText().isEmpty()==true )
			 {b1.setText("Texfields Are Empty!!!"); }
		 
		      
			  else if(t1.getText().isEmpty()==false && t2.getText().isEmpty()==false  && t3.getText().isEmpty()==false )
			  
			   {  

           		String aa=new String();      
                String bb=new String(); 
                String cc=new String();  
				String xx =new String();
				
				
				aa=t1.getText();
				bb=t2.getText();
			    cc=t3.getText();
				 
				
				 String xyx[]=new   String[1000];
				   String ax[]=new String[1000];
				   String bx[]=new String[1000];
				   String cx[]=new String[1000];
				
				
				
				 
				int i=0,j=0;
				int xy=0;
				boolean problem=false;
				
				  
				  try{   File myFilex=new File("allstudentsinfo.txt");
					   Scanner m1x=new Scanner(myFilex);
					   while(m1x.hasNextLine()==true )
					   { 
				         
						  xyx[i]=m1x.nextLine();
				           ax[i]=m1x.nextLine();
						   bx[i]=m1x.nextLine();
						   cx[i]=m1x.nextLine();
						   
						   if(xyx[i]==null){break;}
						   i++;
				         
					   }
					    m1x.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
				    
					
					for(j=0; j<i && ax[j]!=null && bx[j]!=null && cx[j]!=null; j++ )
					{
						if(ax[j].equals(aa) || bx[j].equals(bb) )
						{ problem=true; break;    }
						
						
					}
					
					if(problem==true)
					{  b1.setForeground(Color.red);
						b1.setText("Name/ID already taken");
						
						
					}
					
				   
				   
				   
				   else if(problem==false)
				   {		try{   File myFile=new File("sserial.txt");
					   Scanner m=new Scanner(myFile);
					   while(m.hasNextLine())
					   { xx=m.nextLine();
				         
						 xy=Integer.parseInt(xx);
				    
				         
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       } 
				
				
				
				 xy=xy+1;
				 
  
         
          try{
														// Create file 
											FileWriter fstream = new FileWriter("allstudentsinfo.txt",true);
											BufferedWriter out = new BufferedWriter(fstream);
											out.write(xy+"\n");
											out.write(aa+"\n");
											out.write(bb+"\n");
											out.write(cc+"\n");
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 	


 try{
														// Create file 
											FileWriter fstream2 = new FileWriter("sserial.txt");
											BufferedWriter out2 = new BufferedWriter(fstream2);
											out2.write(xy+"\n");
											 
											 
											//Close the output stream
												out2.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}


  try{
														// Create file 
											FileWriter fstream3 = new FileWriter("allstudentsinfo2.txt",true);
											BufferedWriter out3 = new BufferedWriter(fstream3);
											 
											out3.write(aa+"\n");
											out3.write(bb+"\n");
											out3.write("0\n");
											 
											//Close the output stream
												out3.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 	String gg=new String("000-000-000-000-000");


 try{
														// Create file 
											FileWriter fstream4 = new FileWriter("allstudentsinfo3.txt",true);
											BufferedWriter out4 = new BufferedWriter(fstream4);
											out4.write(xy+"\n");
											out4.write(aa+"\n");
											out4.write(bb+"\n");
											out4.write("Programming-1"+"\n");
											out4.write(gg+"\n");
											out4.write("Math-1"+"\n");
											out4.write(gg+"\n");
											out4.write("Physics-1"+"\n");
											out4.write(gg+"\n");
											out4.write("ICS"+"\n");
											out4.write(gg+"\n");
											out4.write("English-1"+"\n");
											out4.write(gg+"\n");
											
											//Close the output stream
												out4.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}








							 														
			 
				   b1.setText("Registration Successful"); }
				
			}
			 
			} 
		
			else if(ae.getSource()==b2)
					 {
						 aMenu d=new aMenu();
						 this.setVisible(false);
						 d.setVisible(true);
						 
						 
					 }
					 
					 
			 		 
			 
			 
			
			
		}
 
	 
 public static void main(String[] args)
 {
	 addStudent l=new addStudent();
	 
	 
 }
 
 
 
 
 }


 