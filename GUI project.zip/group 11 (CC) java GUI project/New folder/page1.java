import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
 
//import java.util.Scanner;
import java.io.*; 


 
 class page1 extends JFrame implements ActionListener
 {  JButton b1,b2,b3,b4; 
  JTextField t1,t2;
   JLabel l1,l2,l3;
	  JPanel p1,p2;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
		 
	
		public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 	 
	
	 page1()
	{    super("Front Page");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,60);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   setResizable(false);
	   setLocationRelativeTo(null);
	   
	   
	    heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,0));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("Welcome to AIUB Portal");
		 header.setBounds( 400,3,900,80);
		header.setFont(f);
		header.setForeground(Color.YELLOW);
		//heading.add(header);
		
		
		 
		 
		
		 ImageIcon background_image=new ImageIcon("page1.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		
		 
	    
		
		
	    
		
		
		  p1=new JPanel();
		// p1.setSize(600,500);
		 p1.setBounds(400,180,700,800);
		  p1.setBackground(new Color(0,0,0,60));
		p1.setLayout(null);
		 
		 
		 
		 
		   b1=new JButton("Log In");
		  b1.setBounds(180,140,300,50);
		  b1.setFont(f2);
		  //b3.setVisible(false);
		  b1.addActionListener(this);
		  
		      ylw(b1);
		  
		  p1.add(b1);
		 
		 
		 
		 
		 
		   b2=new JButton("Notice Board");
		  b2.setBounds(180,240,300,50);
		  b2.setFont(f2);
		  //b3.setVisible(false);
		  b2.addActionListener(this);
		  
		      ylw(b2);
		  
		  p1.add(b2);
		 
		 
		 
		 
		 
		  b3=new JButton("General Info");
		  b3.setBounds(180,340,300,50);
		  b3.setFont(f2);
		  //b3.setVisible(false);
		  b3.addActionListener(this);
		  
		  
		       ylw(b3);
		  
		  p1.add(b3);
		 
		 
		 
		 
		   b4=new JButton("About Us");
		  b4.setBounds(180,440,300,50);
		  b4.setFont(f2);
		  //b3.setVisible(false);
		  b4.addActionListener(this);
		  
	 
         ylw(b4);


		  p1.add(b4);
		
		
		
		
		 
		 
		
		 
		 
	 
		
		this.add(p1);
		
		 
		 
		  background.add(header);
		 add(background);
		setVisible(true);
	}
	
	
	 public void actionPerformed(ActionEvent ae)
		{  if(ae.getSource()==b1 )
			{   b1.setBackground(Color.yellow);
		        b2.setBackground(Color.white);
				b3.setBackground(Color.white);
				
				logIn l=new logIn();
				this.setVisible(false);
				 l.setVisible(true);
		        }
		
		
		else if(ae.getSource()==b2 )
			{   b2.setBackground(Color.yellow);
		      
		        b1.setBackground(Color.white);
				b3.setBackground(Color.white);
				
				readNotice ld=new readNotice();
				this.setVisible(false);
				ld.setVisible(true);
		
		    }
			
			
			else if(ae.getSource()==b3 )
			{   b3.setBackground(Color.yellow);
		      
		        b1.setBackground(Color.white);
				b1.setBackground(Color.white);
		       FST fx=new FST();
		    }
		
		
		else if(ae.getSource()==b4 )
			{   b4.setBackground(Color.yellow);
		       
		        b2.setBackground(Color.white);
				b1.setBackground(Color.white);
				
				 
			aboutUs fx=new aboutUs();
			 this.setVisible(false);
				 fx.setVisible(true);
			
		} }
	
	public static void main(String[] args)
 {
	page1 p=new page1();
	 
	 
	 
 }
 
 }
	