import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 import java.io.File; 
 import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.*; 
import javax.swing.JScrollPane;
 import javax.swing.JFrame; 
import javax.swing.JTable; 
import javax.swing.table.*;
 


 
 class marksy extends JFrame implements ActionListener
 {  JButton b1,b2,b3,b4,lx; 
  JTextField t1,t2;
   JLabel l1,l2,l3;
	  JPanel p1,p2;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
	  JTable tb1;
	  JScrollPane jscp;
	  String name,id,password,roll;
	  
	  String[] colm={"Subject","Quiz 1","Quiz 2","Quiz 3","A/P", "Term Assessment","Grade"};
	   
	  String[][] row={   
		                      
		  
		  
		  {"Programming-1","13","27","10","20","0",""},
		   {"Math-1","10","40","10","20","30",""},
		    {"Physics-1","10","40","10","20","10",""},
			 {"ICS","7","10","10","20","33",""},
			  {"English-1","10","20","13","20","43",""},
				 
		  
		   
		  
	  };
		 
	
	public static String cut(String s, int x, int y)
	{
		
		 String ss=s.substring(x-1,y);
		 int xx=Integer.parseInt(ss);
		 
		 return String.valueOf(xx);
		
		
	}
	
	public static String cutCalcGrade(String s)
	{
		 String ss=new String(s.substring(1,3));  
		 int x1=Integer.parseInt(ss);  
		 
		  String ss2=new String(s.substring(5,7));
		 int x2=Integer.parseInt(ss2);  
		 
		 String ss3=new String(s.substring(9,11));
		 int x3=Integer.parseInt(ss3); 
		 
		  String ss4=new String(s.substring(13,15));
		 int x4=Integer.parseInt(ss4);  
		 
		 String ss5=new String(s.substring(17,19));
		 int x5=Integer.parseInt(ss5);  
		 
		 int sum=x1+x2+x3+x4+x5;    
		 
		 if(sum<=100 && sum>=90) {return "A+";}
		 
		 else if(sum<90 && sum>=85) {return "A";}
		 
		  else if(sum<85 && sum>=80) {return "B+";}
		  
		   else if(sum<80 && sum>=75) {return "B";}
		   
		    else if(sum<75 && sum>=70) {return "C+";}
			 else if(sum<70 && sum>=65) {return "C";}
			 
			  else if(sum<65 && sum>=60) {return "D+";}
			  
			  else if(sum<60 && sum>=50) {return "D";}
			  
			   else if(sum<50 && sum>=0) {return "F";}
			   
			   return "0";
		
		
		
	}
	
	
	public static double cutCalcGradePoint(String s)
	{
		 String ss=new String(s.substring(1,3));  
		 int x1=Integer.parseInt(ss);  
		 
		  String ss2=new String(s.substring(5,7));
		 int x2=Integer.parseInt(ss2);  
		 
		 String ss3=new String(s.substring(9,11));
		 int x3=Integer.parseInt(ss3); 
		 
		  String ss4=new String(s.substring(13,15));
		 int x4=Integer.parseInt(ss4);  
		 
		 String ss5=new String(s.substring(17,19));
		 int x5=Integer.parseInt(ss5);  
		 
		 int sum=x1+x2+x3+x4+x5;    
		 
		 if(sum<=100 && sum>=90) {return 4.0;}
		 
		 else if(sum<90 && sum>=85) {return 3.75;}
		 
		  else if(sum<85 && sum>=80) {return 3.5;}
		  
		   else if(sum<80 && sum>=75) {return 3.25;}
		   
		    else if(sum<75 && sum>=70) {return 3.0;}
			 else if(sum<70 && sum>=65) {return 2.75;}
			 
			  else if(sum<65 && sum>=60) {return 2.5;} 
			  
			  else if(sum<60 && sum>=50) {return 2.25;}
			  
			   else if(sum<50 && sum>=0) {return 0.0;}
			   
			   return 0.0;
		
		
		
	}
	
	public void cyan(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.cyan);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 
	
	
		public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 	 
	
	 marksy(String abc, String def, String ghi)
	{    super("Admin Viewing Marks");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,60);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   setResizable(false);
	   setLocationRelativeTo(null);
	   
	   
	    heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,0));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("Student's Result");
		 header.setBounds( 500,3,900,80);
		header.setFont(f);
		header.setForeground(Color.yellow);
		//heading.add(header);
		
		
		 
		 
		
		 ImageIcon background_image=new ImageIcon("page4.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		
		 
		 
		 
		 name=abc;
		 id=def;
		 password=ghi;
		  
	    
		 
		
		
		int i=0,j=0;
		
		
					 String course1=new String();
					 String course2=new String();
			         String course3=new String();
					 String course4=new String();
					 String course5=new String();
					 
					 String marksArray1=new String();
					 String marksArray2=new String();
					 String marksArray3=new String();
					 String marksArray4=new String();
					 String marksArray5=new String();
					 
		 
			 
			 
			 
			
			       String aa[]=new String[100];
				   String bb[]=new String[100];
				   String cc[]=new String[100];
				   String dd[]=new String[100];
				   String ee[]=new String[100];
				   String ff[]=new String[100];
				   String gg[]=new String[100];
				   String hh[]=new String[100];
				   String ii[]=new String[100];
				   String jj[]=new String[100];
				   String kk[]=new String[100];
				   String ll[]=new String[100];
				   String mm[]=new String[100];
				  
			
			
			
			try{   File myFile=new File("allstudentsinfo3.txt");
					   Scanner m=new Scanner(myFile);
					   while(m.hasNextLine())
					   {  aa[i]=m.nextLine(); 
				          bb[i]=m.nextLine(); 
                          cc[i]=m.nextLine();
						  dd[i]=m.nextLine();  
						  ee[i]=m.nextLine();
						  ff[i]=m.nextLine();
                          gg[i]=m.nextLine();
                          hh[i]=m.nextLine();
                          ii[i]=m.nextLine();
                          jj[i]=m.nextLine();
                          kk[i]=m.nextLine();
                          ll[i]=m.nextLine();
                          mm[i]=m.nextLine();						  
				     
						   i++;
						   
						   
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }  
									   
									   
				for(j=0; j<=i && aa[j]!=null && mm[j]!=null; j++)	
                {
					if(cc[j].equals(id) || bb[j].equals(name))
					{
						 
						
						course1=dd[j];  
						marksArray1=ee[j];
						course2=ff[j];
						marksArray2=gg[j];
						course3=hh[j];
						marksArray3=ii[j];
						course4=jj[j];
						marksArray4=kk[j];
						course5=ll[j];
						marksArray5=mm[j];
						
						 
						
					}
					else{continue; }
					
					
					j++;
					
					
				}					
		 
	 
		 
		
		String q1c1=new String(cut(marksArray1,1,3));
		String q2c1=new String(cut(marksArray1,5,7));
		String q3c1=new String(cut(marksArray1,9,11));
		String apc1=new String(cut(marksArray1,13,15));
		String asc1=new String(cut(marksArray1,17,19));


		String q1c2=new String(cut(marksArray2,1,3));
		String q2c2=new String(cut(marksArray2,5,7));
		String q3c2=new String(cut(marksArray2,9,11));
		String apc2=new String(cut(marksArray2,13,15));
		String asc2=new String(cut(marksArray2,17,19));
		


		String q1c3=new String(cut(marksArray3,1,3));
		String q2c3=new String(cut(marksArray3,5,7));
		String q3c3=new String(cut(marksArray3,9,11));
		String apc3=new String(cut(marksArray3,13,15));
		String asc3=new String(cut(marksArray3,17,19));
		


		String q1c4=new String(cut(marksArray4,1,3));
		String q2c4=new String(cut(marksArray4,5,7));
		String q3c4=new String(cut(marksArray4,9,11));
		String apc4=new String(cut(marksArray4,13,15));
		String asc4=new String(cut(marksArray4,17,19));
		


		String q1c5=new String(cut(marksArray5,1,3));
		String q2c5=new String(cut(marksArray5,5,7));
		String q3c5=new String(cut(marksArray5,9,11));
		String apc5=new String(cut(marksArray5,13,15));
		String asc5=new String(cut(marksArray5,17,19));
		
		
        String grade1=new String(cutCalcGrade(marksArray1));
		String grade2=new String(cutCalcGrade(marksArray2));
		String grade3=new String(cutCalcGrade(marksArray3));
		String grade4=new String(cutCalcGrade(marksArray4));
		String grade5=new String(cutCalcGrade(marksArray5));
		
		double gp1= cutCalcGradePoint(marksArray1);
		double gp2= cutCalcGradePoint(marksArray2);
		double gp3= cutCalcGradePoint(marksArray3);
		double gp4= cutCalcGradePoint(marksArray4);
	    double gp5= cutCalcGradePoint(marksArray5);
		
		float cgpa=0.0f;
		
		
		 
		
		
		
		
		
		
		String nameXY[]=new String[1000];
		String idXY[]=new String[1000];
		String cgpaXY[]=new String[1000];
		
		i=0; j=0; String sh=new String();
		
		try{   File myFile=new File("allstudentsinfo2.txt");
					   Scanner m=new Scanner(myFile);
					   
					   while(m.hasNextLine())
					   {  nameXY[i]=m.nextLine(); 
				          idXY[i]=m.nextLine(); 
                          cgpaXY[i]=m.nextLine();  
						  					  
				              if(nameXY[i].equals(name)){ cgpa=Float.parseFloat( cgpaXY[i]);  sh=cgpaXY[i]; break;}
						   i++;
						   
						   
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       } 
									   
			 
	 
		
		 String[][] row2={   
		                      
		  
		  
		  {course1,q1c1,q2c1,q3c1,apc1,asc1,grade1},
		   {course2,q1c2,q2c2,q3c2,apc2,asc2,grade2},
		    {course3,q1c3,q2c3,q3c3,apc3,asc3,grade3},
			 {course4,q1c4,q2c4,q3c4,apc4,asc4,grade4},
			  {course5,q1c5,q2c5,q3c5,apc5,asc5,grade5},
				 
		  
		   
		  
	  };   row=row2;
		
		
	 
		
		
		  p1=new JPanel();
		// p1.setSize(600,500);
		 p1.setBounds(0,120,1700,800);
		  p1.setBackground(new Color(0,0,0,60));
		p1.setLayout(null);
		 
		 
		 	lx=new JButton("CGPA : "+sh);
		lx.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		lx.setForeground(Color.black);
		lx.setBounds(580,420,300,50);
		lx.setBackground(Color.white);
		//cyan(lx);
		p1.add(lx);
		
		l3=new JLabel(name+" :");
		l3.setFont(new Font("Comic Sans MS",Font.BOLD,35));
		l3.setForeground(Color.yellow);
		l3.setBounds(580,27,1000,50);
		 
		//cyan(lx);
		p1.add(l3);
 
		 
		 tb1=new JTable(row,colm);
		 tb1.setFont(f2);
		 tb1.getTableHeader().setFont(f2);
		 tb1.setEnabled(false);
		 tb1.setSelectionBackground(Color.green);
		 tb1.setRowHeight(50);
		  
		  
tb1.getColumnModel().getColumn(0).setPreferredWidth(250);
tb1.getColumnModel().getColumn(5).setPreferredWidth(250);
		  
		  
		 DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(5).setCellRenderer(centerRenderer); 

		 DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
centerRenderer2.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(6).setCellRenderer(centerRenderer2); 

DefaultTableCellRenderer centerRenderer3 = new DefaultTableCellRenderer();
centerRenderer3.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(4).setCellRenderer(centerRenderer3); 

	 

 

		    jscp= new JScrollPane(tb1);
			jscp.setBounds(230,80,1000,310);
			jscp.setFont(f2);
			  jscp.setPreferredSize(new Dimension(1000, 700));
			p1.add(jscp);
		 
		 
		 
		   b4=new JButton("Back");
		  b4.setBounds(580,500,300,50);
		  b4.setFont(f2);
		  //b3.setVisible(false);
		  b4.addActionListener(this);
		  
	 
         ylw(b4);


		  p1.add(b4);
		
		
		
		
		 
		 
		 
		 
	 
		
		this.add(p1);
		
		 
		 
		  background.add(header);
		 add(background);
		setVisible(true);
	}
	
	
	 public void actionPerformed(ActionEvent ae)
		{   
		
	 if(ae.getSource()==b4 )
			{   b4.setBackground(Color.yellow);
		       
		     //   b2.setBackground(Color.white);
			//	b1.setBackground(Color.white);
				
				 		
				
				 
			marksx fx=new marksx();
			 this.setVisible(false);
				 fx.setVisible(true);
			
		} }
	
	public static void main(String[] args)
 {
	marksy pq=new marksy(marksx.n, marksx.n2, marksx.n3);
	 
	 
	 
 }
 
 }
	