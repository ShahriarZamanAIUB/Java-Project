 import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
import java.util.Scanner;
import java.io.*; 


 
 class logIn extends JFrame implements ActionListener
 {  
  JButton b1,b2,b3; 
  JTextField t1;
   JLabel l1,l2,l3;
	  JPanel p1,p2;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
	  JPasswordField t2;
		 
		 
			public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 	 
		 
		 
	
	 logIn()
	{  super("Log In Page");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,50);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,70));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("LOG  IN  PAGE");
		 header.setBounds( 500,3,500,80);
		header.setFont(f);
		header.setForeground(Color.BLUE);
		//heading.add(header);
		
		 
		
		 ImageIcon background_image=new ImageIcon("page2.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		 
		 //
		 
	      p1=new JPanel();
	     p1.setSize(600,500);
		 p1.setBounds(400,200,700,800);
		 p1.setBackground(new Color(0,0,0,30));
		 p1.setLayout(null);
		 
		  p2=new JPanel();
		// p1.setSize(600,500);
		 p2.setBounds(400,200,700,800);
		  p2.setBackground(new Color(0,0,0,0));
		 p2.setLayout(null);
		 
		  l1 = new JLabel("Enter Your ID :");
		l1.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l1.setForeground(Color.white);
		l1.setBounds(90,100,1000,50);
		p1.add(l1);
		
		 
		 t1=new JTextField( );
		 t1.setFont(f2);
		 t1.setBounds(320,100,250,50);
	     t1.addActionListener(this);
		 p1.add(t1);
		 
		 l2 = new JLabel("Enter Password:");
		l2.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l2.setForeground(Color.white);
		l2.setBounds(90,170,1000,50);
		p1.add(l2);
		 
		  t2=new JPasswordField( );
		  t2.setFont(f2);
		  t2.setBounds(320,170,250,50);
	      t2.addActionListener(this);
		  p1.add(t2);
		 
		 
		 
		 b1=new JButton("Log In");
		 b1.setBounds(180,280,300,50);
		  b1.setFont(f2);
		  b1.addActionListener(this);
		  
		   ylw(b1);
		  
		 p1.add(b1);
		 
		 l3 = new JLabel( );
		l3.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l3.setForeground(Color.white);
		l3.setBounds(200,400,250,50);
		p1.add(l3);
		
		 b2=new JButton("Proceed");
		 b2.setBounds(180,350,300,50);
		  b2.setFont(f2);
		  b2.setVisible(false);
		  b2.addActionListener(this);
		  
		       ylw(b2);
		  
		  p2.add(b2);
		  
		  
		   b3=new JButton("Back");
		  b3.setBounds(180,350,300,50);
		  b3.setFont(f2);
		  b3.setVisible(false);
		  b3.addActionListener(this);
		  
		      ylw(b3);
		  p2.add(b3);
		 
		 
		 
	 
		//
		 
		 
		 
	 
		
	 
		
		  this.add(p1);
		  this.add(p2);
		  background.add(header);
		 add(background);
		 
		setVisible(true);
		
		
	}
 
 
      void Delay(Long ms){

       Long dietime = System.currentTimeMillis()+ms;
       while(System.currentTimeMillis()<dietime){
           //do nothing
       }
   }

 
 
 public void actionPerformed(ActionEvent ae)
		{     
		    
				   
			
			if(ae.getSource()==b1)
			{       int i=0,j=0; boolean x=false;
				     int xy[]=new    int[100];
				   String a[]=new String[100];
				   String b[]=new String[100];
				   String c[]=new String[100];
				   String xx =new String();
				      
					 
					  
					  
					 
					 String id=new String();
					 id=t1.getText();
					 
					 
					 String pin=new String();
				       pin=t2.getText();
					   
					 if(id.equals("000") && pin.equals("asdf") || id.equals("a") && pin.equals("1")) 
					 { try{    	// Create file 
											FileWriter fstream = new FileWriter("loginstatus.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											out.write("3");
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 
				 
				 
				 
				 
				      aMenu amn=new aMenu(); 
				        this.setVisible(false);
						amn.setVisible(true);
				 
				 
				 
				     }
					   
					   
					 else if(id.equals("55555") && pin.equals("pass") || id.equals("t") && pin.equals("2") ) 
                     
                      { try{    	// Create file 
											FileWriter fstream = new FileWriter("loginstatus.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											out.write("2");
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 
				 
				 
				 
				 
				      tMenu tmn=new tMenu(); 
				        this.setVisible(false);
						tmn.setVisible(true);
				 
				 
				 
				     }				 
					   
					   
					   
					   
					   
					   
					   
					   
					   
					   
					 else {
					   
					   
					   
					try{   File myFile=new File("allstudentsinfo.txt");
					   Scanner m=new Scanner(myFile);
					   while(m.hasNextLine())
					   { xx=m.nextLine();
				         
						 xy[i]=Integer.parseInt(xx);
				    
				         a[i]=m.nextLine();
				         b[i]=m.nextLine();
						 c[i]=m.nextLine();
				     
						   i++;
						   
						   
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       } 
					
					
					   
					   
					   for(j=0; a[j]!=null && b[j]!=null && c[j]!=null && j<=i; j++)
					   {
						  if(id.equals(b[j]) && pin.equals(c[j]))
						  {
							  x=true; 
 
									try{
														// Create file 
											FileWriter fstream = new FileWriter("loginstatus.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											out.write("1");
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 
																						
											try{
														// Create file 
											FileWriter fstream = new FileWriter("slogininfo.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											out.write(xy[j]+"\n");
											out.write(a[j]+"\n");
											out.write(b[j]+"\n");
											out.write(c[j]+"\n");
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 											
																						
																						
														 		
																						
																						break;
						  }
  
						}
						  
						   
					   
					   
					   
					   
					   
				      //String a=new String("20-41840-1");
					  //String b=new String("51797167");
					  
					    
				 if(x==true)
				 {   
			     b1.setForeground(Color.green);
				 b1.setFont(new Font("Arial Rounded MT Bold",Font.BOLD,25));
				  
				  
				     b1.setText("Log In Successful");
				 b1.setBackground(Color.yellow);  
			b2.setVisible(true); } 
				 
				 else if(t1.getText()==null || t2.getText()==null )
				 { b1.setText("No Input Detected");  
			 	   b1.setBackground(Color.red); b3.setVisible(true);}
				   
				 else if(x==false)
			  {   //t2.setText("***********"); 
         		  b1.setText("Log In Unuccessful");  
			 	   b1.setBackground(Color.red);
				   
				    b3.setVisible(true);
				 
			   }
				     
			 
					   }
			}
		
			else if(ae.getSource()==b2)
					 {
						 sMenu d=new sMenu();
						 this.setVisible(false);
						 d.setVisible(true);
						 
						 
					 }
					 
					 
			else if(ae.getSource()==b3)
					 {
						 page1 d=new page1();
						 this.setVisible(false);
						 d.setVisible(true);
						 
						 
					 }		 
			 
			 
			
			
		}
 
	 
 public static void main(String[] args)
 {
	 logIn l=new logIn();
	 
	 
 }
 
 
 
 
 }


 