 import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
import java.util.Scanner;
import java.io.*; 


 
 class addNotice extends JFrame implements ActionListener
 {  
  JButton b1,b2,b3; 
  JTextField t1,t2,t3;
   JLabel l1,l2,l3;
	  JPanel p1,p2;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
	  JTextArea ta1; 
		 
		 
			public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 	 
		 
		 
	
	 addNotice()
	{  super("Adding Notice");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,50);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,70));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("Adding Notice");
		 header.setBounds( 520,3,600,80);
		header.setFont(f);
		header.setForeground(Color.green);
		//heading.add(header);
		
		 
		
		 ImageIcon background_image=new ImageIcon("page6.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		 
		 //
		 
	      p1=new JPanel();
	     p1.setSize(800,500);
		 p1.setBounds(250,200,1000,800);
		 p1.setBackground(new Color(0,0,0,50));
		 p1.setLayout(null);
		 
		  p2=new JPanel();
		// p1.setSize(600,500);
		 p2.setBounds(400,200,700,600);
		  p2.setBackground(new Color(0,0,0,0));
		 p2.setLayout(null);
		 
		 
		 
		ta1=new JTextArea(700,300);
		ta1.setBounds(170,80,700,300);
		ta1.setFont(f2);
		ta1.setLineWrap(true);
		ta1.setWrapStyleWord(true);
		 
		p1.add(ta1);
		 
		 
		  
		  
		   
		 
		 
		 
	 
		b1=new JButton("Publish");
		  b1.setBounds(320,420,300,50);
		  b1.setFont(f2);
		   
		  b1.addActionListener(this);
		  
		      ylw(b1);
		  p1.add(b1);
	 
		  
		  
		   b2=new JButton("Back");
		  b2.setBounds(170,500,300,50);
		  b2.setFont(f2);
		   
		  b2.addActionListener(this);
		  
		      ylw(b2);
		  p2.add(b2);
		 
		 
		 
	 
		//  
		 
		 
		 
	 
		
	 
		
		  this.add(p1);
		  this.add(p2);
		  background.add(header);
		 add(background);
		 
		setVisible(true);
		
		
	}
 
 
      void Delay(Long ms){

       Long dietime = System.currentTimeMillis()+ms;
       while(System.currentTimeMillis()<dietime){
           //do nothing
       }
   }
 
 
 public void actionPerformed(ActionEvent ae)
		{     
		    if(ae.getSource()==b1)
			{
				ta1.setEditable(false);
				try {
                    BufferedWriter fileOut = new BufferedWriter(new FileWriter("noticeboard.txt"));
                         
						 
						 String m1=ta1.getText();
						 String m2=m1.replace(System.getProperty("line.separator"),System.getProperty("line.separator"));
						 
						 
						 
						 
						 
						 ta1.write(fileOut);  
						 
						 
 
                     fileOut.close();
                     }

					 catch (IOException ioe) { ioe.printStackTrace();}
				
				b1.setText("Successfully Published");
				b1.setForeground(Color.green);
				ta1.setBackground(Color.pink);
				
				
			}
				   
			 
		
			 else if(ae.getSource()==b2)
					 {
						 aMenu d=new aMenu();
						 this.setVisible(false);
						 d.setVisible(true);
						 
						 
					 }
					 
					 
			 		 
			 
			 
			
			
		}
 
	 
 public static void main(String[] args)
 {
	 addNotice l=new addNotice();
	 
	 
 }
 
 
 
 
 }


 