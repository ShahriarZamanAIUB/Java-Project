import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
import java.util.Scanner;
import java.io.*; 
import java.awt.image.BufferedImage;


 
 class aboutUs extends JFrame implements ActionListener
 {  JButton b1,b2,b3; 
  JTextField t1,t2;
   JLabel l1,l2,l3,P1;
	  JPanel p1,p2,px;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
	  
	public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});}		

		
	
	 aboutUs()
	{   super("About Developers");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,60);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   setResizable(false);
	   setLocationRelativeTo(null);
	   
	   
	    heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,70));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("Project Contributors");
		 header.setBounds( 400,3,900,80);
		header.setFont(f);
		header.setForeground(Color.BLUE);
		//heading.add(header);
		
		
		 
		 
		
		 ImageIcon background_image=new ImageIcon("page2.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		
		 
	   JLabel l1=new JLabel();
       l1.setBounds(850,160,250,250);	
	   
	   
         l1.setIcon(resize(new ImageIcon("Zaman.jpg"),l1.getWidth(),l1.getHeight()));   
		 
		 JLabel l2=new JLabel();
       l2.setBounds(850,440,250,250);
	   
	 l2.setIcon(resize(new ImageIcon("Mahmudul.jpg"),l2.getWidth(),l2.getHeight()));	   
		 
		 
		  JLabel l3=new JLabel("Muhammad Shahriar Zaman");
		  l3.setBounds(250,160,1000,60);
		  l3.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		l3.setForeground(Color.yellow);
		
		 JLabel l3b=new JLabel("20-41840-1");
		  l3b.setBounds(250,240,1000,60);
		  l3b.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		l3b.setForeground(Color.yellow);
		
		 JLabel l3c=new JLabel("Roll No. 5");
		  l3c.setBounds(250,320,1000,60);
		  l3c.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		l3c.setForeground(Color.yellow);
		
		
		  JLabel l4=new JLabel("Mahumudul Hasan Shohan");
		    l4.setBounds(250,440,1000,60); 
		    l4.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		l4.setForeground(Color.white);
		
		
		 JLabel l4b=new JLabel("20-41876-1");
		  l4b.setBounds(250,520,1000,60);
		  l4b.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		l4b.setForeground(Color.white);
		
		JLabel l4c=new JLabel("Roll No. 7");
		  l4c.setBounds(250,600,1000,60);
		  l4c.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		l4c.setForeground(Color.white);
		
		
	    
		
		
		  p2=new JPanel();
		// p1.setSize(600,500);
		 p2.setBounds(400,380,700,800);
		  p2.setBackground(new Color(0,0,0,0));
		 p2.setLayout(null);
		 
		   b3=new JButton("Back");
		  b3.setBounds(180,350,300,50);
		  b3.setFont(f2);
		   
		  b3.addActionListener(this);
		  ylw(b3);
		  p2.add(b3);
		
		
		
		
		//
		 
		
		 
		 
	 
		
		this.add(p2);
		
		 
		 add(l1); add(l2); add(l3); add(l4); add(l3b); add(l4b); add(l3c); add(l4c);     
		  background.add(header);
		 add(background);
		setVisible(true);
	}
	
	public  static  ImageIcon resize(ImageIcon im,int w,int h)
	{
		BufferedImage bi= new BufferedImage(w,h,BufferedImage.TRANSLUCENT);
		Graphics2D gd=(Graphics2D)bi.createGraphics();
		gd.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY));
		gd.drawImage(im.getImage(),0,0,w,h,null);
		gd.dispose();
		return new ImageIcon(bi);
		
		
		
	}
	
	
	 public void actionPerformed(ActionEvent ae)
		{  if(ae.getSource()==b3)
			{  
		 
		         b3.setBackground(Color.yellow);
				 page1 d=new page1();
						 
				
				
				
			}	 


	 	}
	
	public static void main(String[] args)
 {
	aboutUs p=new aboutUs();
	 
	 
	 
 }
 
 }
	