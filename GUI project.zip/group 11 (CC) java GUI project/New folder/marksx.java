import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 import java.io.File; 
 import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.*; 
import javax.swing.JScrollPane;
 import javax.swing.JFrame; 
import javax.swing.JTable; 
import javax.swing.table.*;
 


 
 class marksx extends JFrame implements ActionListener
 {  JButton b1,b2,b3,b4,lx; 
  JTextField t1,t2;
   JLabel l1,l2,l3,l4;
	  JPanel p1,p2;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
	  JTable tb1;
	  JScrollPane jscp;
	  String name,id,password,roll;
	  
	  
	  String[] colm={"Roll","Name","ID","Password"};
	   
	  String[][] row=new String[1000][4];
	 static String n=new String();
	  static String n2=new String();
	   static String n3=new String();
	  static boolean selected=false;
	  
	    int L=0;
	
	public static String cut(String s, int x, int y)
	{
		
		 String ss=s.substring(x-1,y);
		 int xx=Integer.parseInt(ss);
		 
		 return String.valueOf(xx);
		
		
	}
	
	public static String cutCalcGrade(String s)
	{
		 String ss=new String(s.substring(1,3));  
		 int x1=Integer.parseInt(ss);  
		 
		  String ss2=new String(s.substring(5,7));
		 int x2=Integer.parseInt(ss2);  
		 
		 String ss3=new String(s.substring(9,11));
		 int x3=Integer.parseInt(ss3); 
		 
		  String ss4=new String(s.substring(13,15));
		 int x4=Integer.parseInt(ss4);  
		 
		 String ss5=new String(s.substring(17,19));
		 int x5=Integer.parseInt(ss5);  
		 
		 int sum=x1+x2+x3+x4+x5;    
		 
		 if(sum<=100 && sum>=90) {return "A+";}
		 
		 else if(sum<90 && sum>=85) {return "A";}
		 
		  else if(sum<85 && sum>=80) {return "B+";}
		  
		   else if(sum<80 && sum>=75) {return "B";}
		   
		    else if(sum<75 && sum>=70) {return "C+";}
			 else if(sum<70 && sum>=65) {return "C";}
			 
			  else if(sum<65 && sum>=60) {return "D+";}
			  
			  else if(sum<60 && sum>=50) {return "D";}
			  
			   else if(sum<50 && sum>=0) {return "F";}
			   
			   return "0";
		
		
		
	}
	
	
	public static double cutCalcGradePoint(String s)
	{
		 String ss=new String(s.substring(1,3));  
		 int x1=Integer.parseInt(ss);  
		 
		  String ss2=new String(s.substring(5,7));
		 int x2=Integer.parseInt(ss2);  
		 
		 String ss3=new String(s.substring(9,11));
		 int x3=Integer.parseInt(ss3); 
		 
		  String ss4=new String(s.substring(13,15));
		 int x4=Integer.parseInt(ss4);  
		 
		 String ss5=new String(s.substring(17,19));
		 int x5=Integer.parseInt(ss5);  
		 
		 int sum=x1+x2+x3+x4+x5;    
		 
		 if(sum<=100 && sum>=90) {return 4.0;}
		 
		 else if(sum<90 && sum>=85) {return 3.75;}
		 
		  else if(sum<85 && sum>=80) {return 3.5;}
		  
		   else if(sum<80 && sum>=75) {return 3.25;}
		   
		    else if(sum<75 && sum>=70) {return 3.0;}
			 else if(sum<70 && sum>=65) {return 2.75;}
			 
			  else if(sum<65 && sum>=60) {return 2.5;} 
			  
			  else if(sum<60 && sum>=50) {return 2.25;}
			  
			   else if(sum<50 && sum>=0) {return 0.0;}
			   
			   return 0.0;
		
		
		
	}
	
	public void cyan(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.cyan);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 
	
	
		public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 	 
	
	 marksx()
	{    super("Students List");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,60);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   setResizable(false);
	   setLocationRelativeTo(null);
	   
	   
	    heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,0));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("All Students");
		 header.setBounds( 530,3,900,80);
		header.setFont(f);
		header.setForeground(Color.yellow);
		//heading.add(header);
		
		
		 
		 
		
		 ImageIcon background_image=new ImageIcon("page4.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		
		 
		 
		 
		  
	 
	   int m=0;
	 
	 String ty[]=new String[1000];
	 
	 try{ 
		 
          File im3=new File("allstudentsinfo.txt");
          Scanner gta3=new Scanner(im3);

          while(gta3.hasNextLine())
		  {
			   ty[m]=gta3.nextLine();
			   
			   if(ty[m]==null){break;}
				
				 m++;
			  
			  
		  }		gta3.close();	  
		 
	 }
	  	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
			  	}
				
				m=m/4;
	 
		 
		  
     String row2[][]=new String[m][4];
	 
	 
	 try{ 
		 
          File im=new File("allstudentsinfo.txt");
          Scanner gta=new Scanner(im);

          while(gta.hasNextLine())
		  {
			 row2[L][0]=gta.nextLine(); 
			  row2[L][1]=gta.nextLine();
			   row2[L][2]=gta.nextLine();
			   row2[L][3]=gta.nextLine();
			    
				
				
				L++;
			  
			  
			  
			  
			  
			  
		  }		gta.close();	  
		 
	 }
	  	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
			  	}
				
	 
	 
    

	  row=row2;
		
		 
	 
		
		
		  p1=new JPanel();
		// p1.setSize(600,500);
		 p1.setBounds(0,120,1700,800);
		  p1.setBackground(new Color(0,0,0,60));
		p1.setLayout(null);
		
		
		 p2=new JPanel();
		// p1.setSize(600,500);
		 p2.setBounds(480,400,1000,800);
		  p2.setBackground(new Color(0,0,0,0));
		p2.setLayout(null);
		 
		 
		 	t1=new JTextField();
		t1.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		t1.setForeground(Color.black);
		t1.setBounds(500,420,450,50);
		t1.setBackground(Color.white);
		 t1.setEditable(false);
 
		p1.add(t1);
		
		l3=new JLabel("Select Any Row : ");
		l3.setFont(new Font("Comic Sans MS",Font.BOLD,35));
		l3.setForeground(Color.red);
		l3.setBounds(580,27,1000,50);
		 
		 
		p1.add(l3);
		  
		  
		  l4=new JLabel("->");
		l4.setFont(new Font("Comic Sans MS",Font.BOLD,55));
		l4.setForeground(Color.red);
		l4.setBounds(30,215,307,50);
		 
		  p2.add(l4);
		  
		   b3=new JButton("View His/Her Result");
		  b3.setBounds(97,220,307,50);
		  b3.setFont(f2);
		  b3.setVisible(false);
		  b3.addActionListener(this);
		
		ylw(b3);
		  p2.add(b3);
		
		 
		 
 
		 
		 tb1=new JTable(row2,colm);
		 tb1.setFont(f2);
		 tb1.getTableHeader().setFont(f2);
		// tb1.setEnabled(false);
		
		//DefaultTableModel tbm=new DefaultTableModel();
		 
		 //tb1.setModel(tbm);
		  //tbm.setColumnIdentifiers(colm);
		
		 tb1.setSelectionBackground(Color.green);
		 tb1.setRowHeight(50);
		 
		 
		 tb1.addMouseListener(new MouseAdapter(){
		 
			 
			public void   mouseClicked(MouseEvent me)
			 {int rownumx=0;
			 
			      selected=true;
				 b3.setVisible(true);
				 
				 
				try{rownumx=tb1.getSelectedRow();}
                 catch(NullPointerException n){ System.out.println("Try again");}				
				 
				  n=tb1.getValueAt(rownumx,1).toString();
				  n2=tb1.getValueAt(rownumx,2).toString();
				  n3=tb1.getValueAt(rownumx,3).toString();
				
				 
				 
				 
				t1.setText(n);
				 
				 
				 
				 
				 
			 }
			 
			 
			 
		 }); 
		 
		 
		  
		  
tb1.getColumnModel().getColumn(0).setPreferredWidth(25);
tb1.getColumnModel().getColumn(1).setPreferredWidth(370);
		  
		  
		 DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(2).setCellRenderer(centerRenderer); 

		 DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
centerRenderer2.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(2).setCellRenderer(centerRenderer2); 

DefaultTableCellRenderer centerRenderer3 = new DefaultTableCellRenderer();
centerRenderer3.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(3).setCellRenderer(centerRenderer3); 

 DefaultTableCellRenderer centerRendererx = new DefaultTableCellRenderer();
centerRendererx.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(0).setCellRenderer(centerRendererx);  

	 

 

		    jscp= new JScrollPane(tb1);
			jscp.setBounds(230,80,1000,310);
			jscp.setFont(f2);
			  jscp.setPreferredSize(new Dimension(1000, 700));
			p1.add(jscp);
		 
		 
		 
		   b4=new JButton("Back");
		  b4.setBounds(580,600,300,50);
		  b4.setFont(f2);
		  //b3.setVisible(false);
		  b4.addActionListener(this);
		  
	 
         ylw(b4);


		  p1.add(b4);
		  
		  
		  
	 
        

		  //p1.add(b3);
		
		
		
		
		 
		 
		 
		 
	 
		this.add(p2);
		this.add(p1);
		
		 
		 
		  background.add(header);
		 add(background);
		setVisible(true);
	}
	
	
	 public void actionPerformed(ActionEvent ae)
		{   
		
	 if(ae.getSource()==b4 )
			{   b4.setBackground(Color.yellow);
		       
		     //   b2.setBackground(Color.white);
			//	b1.setBackground(Color.white);
				
				 		
				
				 
			aMenu fx=new aMenu();
			 this.setVisible(false);
				 fx.setVisible(true);
			
		}

    else  if(ae.getSource()==b3 )
			{   b3.setBackground(Color.yellow);
		       
		     //   b2.setBackground(Color.white);
			//	b1.setBackground(Color.white);
				
				 		
				try{int rownum=tb1.getSelectedRow();}
			  
			   
			  
			catch(StringIndexOutOfBoundsException e)
			{
				JOptionPane.showMessageDialog(null, "You haven't selected any row");
				
				
			}
				 
			marksy fx=new marksy(n,n2,n3);
			 this.setVisible(false);
				 fx.setVisible(true);
			
		}


		}
	
	public static void main(String[] args)
 {
	marksx pq=new marksx();
	 
	 
	 
 }
 
 }
	