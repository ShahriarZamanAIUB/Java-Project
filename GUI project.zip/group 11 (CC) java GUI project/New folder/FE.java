import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 
import java.util.Scanner;
import java.io.*; 
import java.awt.image.BufferedImage;


 
 class FE extends JFrame implements ActionListener
 {  JButton b1,b2,b3; 
  JTextField t1,t2;
   JLabel l1,l2,l3,P1;
	  JPanel p1,p2,p3,px;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
		

	public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});}
		
	
	 FE()
	{   super("Academic Information Page-2");
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,60);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   setResizable(false);
	   setLocationRelativeTo(null);
	   
	   
	    heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,50));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("Faculty of Engineering");
		 header.setBounds( 350,3,1300,100);
		header.setFont(f);
		header.setForeground(Color.white);
		//heading.add(header);
		
		
		 
		 
		
		 ImageIcon background_image=new ImageIcon("page2.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		
		 
	   JLabel l=new JLabel();
       l.setBounds(370,140,700,570);	
	   
	   
        l.setIcon(resize(new ImageIcon("FE.png"),l.getWidth(),l.getHeight()));	   
		 
		    
		 
		  
		 p1=new JPanel();
		// p1.setSize(600,500);
		 p1.setBounds(800,385,700,800);
		  p1.setBackground(new Color(0,0,0,0));
		 p1.setLayout(null);
	    
		 b1=new JButton("Next");
		  b1.setBounds(350,340,200,50);
		  b1.setFont(f2);
		  //b3.setVisible(false);
		  b1.addActionListener(this);
		  ylw(b1);
		  p1.add(b1);
		
	    
		  
		 p3=new JPanel();
		// p1.setSize(600,500);
		 p3.setBounds(0,385,700,800);
		  p3.setBackground(new Color(0,0,0,0));
		 p3.setLayout(null);
	    
		 b2=new JButton("Previous");
		  b2.setBounds(150,340,200,50);
		  b2.setFont(f2);
		  //b3.setVisible(false);
		  b2.addActionListener(this);
		  ylw(b2);
		  p3.add(b2);
		
		
		
		
		  p2=new JPanel();
		// p1.setSize(600,500);
		 p2.setBounds(400,380,700,800);
		  p2.setBackground(new Color(0,0,0,0));
		 p2.setLayout(null);
		 
		   b3=new JButton("Back");
		  b3.setBounds(180,340,300,50);
		  b3.setFont(f2);
		  //b3.setVisible(false);
		  b3.addActionListener(this);
		  ylw(b3);
		  p2.add(b3);
		
		
		
		
		//
		 
		
		 
		 
	    this.add(p1);
		
		this.add(p2);
		
		this.add(p3);
		
		 
		 add(l);  
		  background.add(header);
		 add(background);
		setVisible(true);
	}
	
	public  static  ImageIcon resize(ImageIcon im,int w,int h)
	{
		BufferedImage bi= new BufferedImage(w,h,BufferedImage.TRANSLUCENT);
		Graphics2D gd=(Graphics2D)bi.createGraphics();
		gd.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING,RenderingHints.VALUE_RENDER_QUALITY));
		gd.drawImage(im.getImage(),0,0,w,h,null);
		gd.dispose();
		return new ImageIcon(bi);
		
		
		
	}
	
	
	 public void actionPerformed(ActionEvent ae)
		{  if(ae.getSource()==b3)
			{  
		 
		         b3.setBackground(Color.yellow);
				 page1 d=new page1();
						 this.setVisible(false);
				 d.setVisible(true); 
				
				
				
			}	 
			
			
			else  if(ae.getSource()==b2)
			{  
		 
		         b2.setBackground(Color.yellow);
				 FST fx=new FST();
				 this.setVisible(false);
				 fx.setVisible(true);
						 
				
				
				
			}	 
			
			
			else  if(ae.getSource()==b1)
			{  
		 
		         b1.setBackground(Color.yellow);
				 FASS fx=new FASS();
				 this.setVisible(false);
				 fx.setVisible(true);
						 
				
				
				
			}	 


	 	}
	
	public static void main(String[] args)
 {
	FE p=new FE();
	 
	 
	 
 }
 
 }
	