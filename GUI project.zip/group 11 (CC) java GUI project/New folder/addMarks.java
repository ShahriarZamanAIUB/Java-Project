import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
 import java.io.File; 
 import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.*; 
import javax.swing.JScrollPane;
 import javax.swing.JFrame; 
import javax.swing.JTable; 
import javax.swing.table.*;
import java.util.InputMismatchException;
 
 
 

 
 class addMarks extends JFrame implements ActionListener
 {  JButton b1,b2,b3,b4,b5,b6; 
  JTextField t1,t2,t3,t4,t5,t6,t7;
   JLabel l1,l2,l3,l4,l5,lx,lk,lj,lp;
	  JPanel p1,p2,p3;
	  JLabel background;
	   JLabel header;
	  JPanel heading;
	  JTable tb1;
	  static int I=0;
	  static String Name=new String(); 
	  static String course1=new String();
	  static String course2=new String();
	  static String course3=new String();
	  static String course4=new String();
	  static String course5=new String();	  
	  
	  static boolean xmp=false;
	  int spl;
	  
	   DefaultTableModel tbm;
	  JScrollPane jscp;
	  String[] col={"Subject","Quiz 1", "Quiz 2", "Quiz 3", "A/P", "Assessment"};
	  String[][] row=new String[5][6];
	  
	 
	
		public void ylw(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.YELLOW);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 	 
	
	
	public void red(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.RED);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 
	
	
	
	public void cyan(JButton j){   j.addMouseListener(new java.awt.event.MouseAdapter() {
                   public void mouseEntered(java.awt.event.MouseEvent evt) {
                  j.setBackground(Color.cyan);
                   }

                public void mouseExited(java.awt.event.MouseEvent evt) {
              j.setBackground(UIManager.getColor("control"));
    }});} 
	
	public static String cut(String s, int x, int y)
	{
		
		 String ss=s.substring(x-1,y);
		 int xx=Integer.parseInt(ss);
		 
		 return String.valueOf(xx);
		
		
	}
	
	public static boolean isParsable(String input) {
		
		boolean ok; int x;
		
    try {
        x=Integer.parseInt(input);
		 
		  return true; 
        
	   
	
    } catch (final NumberFormatException e) {
          return false;   
    }   
	
	 
	
	
} 
	
	public static double cutCalcGradePoint(String s)
	{
		 String ss=new String(s.substring(1,3));  
		 int x1=Integer.parseInt(ss);  
		 
		  String ss2=new String(s.substring(5,7));
		 int x2=Integer.parseInt(ss2);  
		 
		 String ss3=new String(s.substring(9,11));
		 int x3=Integer.parseInt(ss3); 
		 
		  String ss4=new String(s.substring(13,15));
		 int x4=Integer.parseInt(ss4);  
		 
		 String ss5=new String(s.substring(17,19));
		 int x5=Integer.parseInt(ss5);  
		 
		 int sum=x1+x2+x3+x4+x5;    
		 
		 if(sum<=100 && sum>=90) {return 4.0;}
		 
		 else if(sum<90 && sum>=85) {return 3.75;}
		 
		  else if(sum<85 && sum>=80) {return 3.5;}
		  
		   else if(sum<80 && sum>=75) {return 3.25;}
		   
		    else if(sum<75 && sum>=70) {return 3.0;}
			 else if(sum<70 && sum>=65) {return 2.75;}
			 
			  else if(sum<65 && sum>=60) {return 2.5;} 
			  
			  else if(sum<60 && sum>=50) {return 2.25;}
			  
			   else if(sum<50 && sum>=0) {return 0.0;}
			   
			   return 0.0;
		
		
		
	}
	
	 
	
	public String tripler(String s)
	{
		if(s.length()==3) {return s;}
		
		else if(s.length()==2) {return "0"+s;}
		
		else if(s.length()==1) {return "00"+s;}
		
		
		 
		
		return "000";
		
	}
	
	
	 
	addMarks(String GTA){    super("Marks/Result Publishing");
	
	this.Name=GTA;
	
	Name=new String(GTA);
	
		Font f=new Font("Arial Rounded MT BOLD",Font.BOLD,50);
		Font f2=new Font("Comic Sans MS",Font.BOLD,25);
		
		setSize(1700,850);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	   setResizable(false);
	   setLocationRelativeTo(null);
	   
	   
	    heading=new JPanel();
	   heading.setBackground(new Color(0,0,0,0));
	   heading.setBounds(0,0,1700,120);
		
		
		 header=new JLabel("Publishing Result of "+Name);
		 header.setBounds( 320,0,2000,200);
		header.setFont(f);
		header.setForeground(Color.white);
		//heading.add(header);
		
		
		 
		 
		
		 ImageIcon background_image=new ImageIcon("pagex.jpg");
 
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1700,800,Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		 background=new JLabel("",background_image,JLabel.CENTER);
		
		background.add(heading);
		background.setBounds(0,0,1700,800);
		
		 
	     
		int I=0, J=0;
		
		String aa[]=new String[1000];
		String bb[]=new String[1000];		
		String cc[]=new String[1000];		
		String dd[]=new String[1000];
		String ee[]=new String[1000];
		String ff[]=new String[1000];
		String gg[]=new String[1000];
		String hh[]=new String[1000];
		String ii[]=new String[1000];
		String jj[]=new String[1000];	
		String kk[]=new String[1000];
		String ll[]=new String[1000];
		String mm[]=new String[1000];		
				
			

        String marksArray[]=new String[5];
        

			
			int i=0, j=0;		
				
				
				
				
			  try{   File myFile=new File("allstudentsinfo3.txt");
					   Scanner m=new Scanner(myFile);
					   while(m.hasNextLine())
					   {  aa[i]=m.nextLine(); 
				          bb[i]=m.nextLine(); 
                          cc[i]=m.nextLine();
						  dd[i]=m.nextLine();  
						  ee[i]=m.nextLine();
						  ff[i]=m.nextLine();
                          gg[i]=m.nextLine();
                          hh[i]=m.nextLine();
                          ii[i]=m.nextLine();
                          jj[i]=m.nextLine();
                          kk[i]=m.nextLine();
                          ll[i]=m.nextLine();
                          mm[i]=m.nextLine();						  
				     
						   i++;
						   
						   
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }  
									   
									   
				for(j=0; j<=i && aa[j]!=null && mm[j]!=null; j++)	
                {
					if(bb[j].equals(Name))
					{
						 
						
						course1=dd[j]; 
                         row[0][0]=dd[j];						
						 marksArray[0]=ee[j];
						 
						 
						course2=ff[j];
						 row[1][0]=ff[j];		
						  marksArray[1]=gg[j];
						  
						  
						course3=hh[j];
						 row[2][0]=hh[j];		
						    marksArray[2]=ii[j];
							
							
						course4=jj[j];
						row[3][0]=jj[j];	
						    marksArray[3]=kk[j];
							
							
						course5=ll[j];
						row[4][0]=ll[j];	
						    marksArray[4]=mm[j];
						
						 
						
					}
					else{continue; }
					
					
					j++;
					
					
				}
				
				
				for(i=0; i<=4; i++)
				{    row[i][1]=cut(marksArray[i],1,3);  
                     row[i][2]=cut(marksArray[i],5,7);  
                     row[i][3]=cut(marksArray[i],9,11);  
                     row[i][4]=cut(marksArray[i],13,15);  
                     row[i][5]=cut(marksArray[i],17,19);    }
		
	    
 
		
		  p1=new JPanel();
		// p1.setSize(600,500);
		 p1.setBounds(0,140,1550,800);
		  p1.setBackground(new Color(0,0,0,60));
		p1.setLayout(null);
		
		
		 p2=new JPanel();
		// p1.setSize(600,500);
		 p2.setBounds(0,140,1550,800);
		  p2.setBackground(new Color(0,0,0,0));
		p2.setLayout(null);
		
		 p3=new JPanel();
		// p1.setSize(600,500);
		 p3.setBounds(0,140,1550,800);
		  p3.setBackground(new Color(0,0,0,0));
		p3.setLayout(null);
		 
		 
		  lp = new JLabel("Enter Marks Here: ");
		lp.setFont(new Font("Comic Sans MS",Font.BOLD,40));
		lp.setForeground(Color.white);
		lp.setBounds(20,40,1000,50);
		p1.add(lp);
		
		 
		
		 l3 = new JLabel("Quiz 1 (/20 marks): ");
		l3.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l3.setForeground(Color.yellow);
		l3.setBounds(20,100,1000,50);
		p1.add(l3);
		
		 
		
		l4 = new JLabel("Quiz 2 (/20 marks): ");
		l4.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l4.setForeground(Color.yellow);
		l4.setBounds(20,180,1000,50);
		p1.add(l4);
		
		 
		
		l4 = new JLabel("Quiz 3 (/20 marks): ");
		l4.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l4.setForeground(Color.yellow);
		l4.setBounds(20,260,1000,50);
		p1.add(l4);
		
		 
		
		l4 = new JLabel("A/P (/10 marks): ");
		l4.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l4.setForeground(Color.yellow);
		l4.setBounds(20,340,1000,50);
		p1.add(l4);
		
		 
		
		
		l5= new JLabel("Assessment (/30 marks): ");
		l5.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		l5.setForeground(Color.yellow);
		l5.setBounds(10,420,1000,50);
		p1.add(l5);
		
		lx= new JLabel("First Select a Row : ");
		lx.setFont(new Font("Comic Sans MS",Font.BOLD,40));
		lx.setForeground(Color.white);
		lx.setBounds(780,40,1000,60);
		p1.add(lx);
		
		 
		
		
		
		
		t3=new JTextField();
		t3.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		t3.setBounds(330,100,200,50);
		p1.add(t3);
		
		
		
		
		
		t4=new JTextField();
		t4.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		t4.setBounds(330,180,200,50);
		p1.add(t4);
		
		t5=new JTextField();
		t5.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		t5.setBounds(330,260,200,50);
		p1.add(t5);
		
		
		
		
		t6=new JTextField();
		t6.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		t6.setBounds(330,340,200,50);
		p1.add(t6);
		
		t7=new JTextField();
		t7.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		t7.setBounds(330,420,200,50);
		p1.add(t7);
		
	/*	b1=new JButton("Add");
		b1.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		b1.setBounds(90,560,200,50);
		b1.addActionListener(this);
		ylw(b1);
		p1.add(b1); */
		
		
		b2=new JButton("Clear TextFields");
		b2.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		b2.setBounds(360,560,250,50);
		b2.addActionListener(this);
		ylw(b2);
		p1.add(b2);
		
		
		/*b3=new JButton("Remove");
		b3.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		b3.setBounds(630,560,200,50);  
		b3.addActionListener(this);
		ylw(b3);
		p1.add(b3); */
		
		 
		
		b4=new JButton("Put Values in Row");
		b4.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		 
		b4.setBounds(680,560,400,50);
		b4.addActionListener(this);
		ylw(b4);
		b4.setVisible(false);
		p2.add(b4);
		
		b5=new JButton("Back");
		b5.setFont(new Font("Comic Sans MS",Font.BOLD,25));
		b5.setBounds(1150,560,200,50);
		b5.addActionListener(this);
		red(b5);
		p1.add(b5);
		
        b6=new JButton("Publish");
        b6.setFont(new Font("Comic Sans MS",Font.BOLD,25));		
		b6.setBounds(900,450,300,60);
		b6.addActionListener(this);
		cyan(b6);
		 
		p1.add(b6);
		
		
		 tb1=new JTable(row,col);
		 
		 
		 tb1.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		  tb1.getTableHeader().setFont(new Font("Comic Sans MS",Font.BOLD,20));
		   tb1.setSelectionBackground(Color.YELLOW);
		 tb1.setBackground(Color.white);
		 tb1.setRowHeight(60);
		 
		 tb1.getColumnModel().getColumn(0).setPreferredWidth(250);
		 
		 tb1.addMouseListener(new MouseAdapter(){
		 
			 
			public void   mouseClicked(MouseEvent me)
			 {
				int rownumx=tb1.getSelectedRow(); 
				 
				 String q1=tb1.getValueAt(rownumx,1).toString();  
				 String q2=tb1.getValueAt(rownumx,2).toString();
				 String q3=tb1.getValueAt(rownumx,3).toString();
				 String ap=tb1.getValueAt(rownumx,4).toString();
				  String as=tb1.getValueAt(rownumx,5).toString();
				 
				 
				 
				 t3.setText(q1);
				 t4.setText(q2);
				 t5.setText(q3);
				 t6.setText(ap);
				  t7.setText(as);
				 
				 b4.setVisible(true); 
				 
				  
				  
                  				 
			 }
			 
			 
			 
		 });
		  
		 
 
 
 
		   
		 
		 jscp=new JScrollPane(tb1);
		 jscp.setBounds(580,100,880,335);
		 jscp.setFont(f2);
		  jscp.setPreferredSize(new Dimension(1000, 900));
		 
		 p1.add(jscp);
		 
		 
		 
		   		DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
 tb1.getColumnModel().getColumn(1).setCellRenderer(centerRenderer); 

	 

DefaultTableCellRenderer centerRenderer2 = new DefaultTableCellRenderer();
centerRenderer2.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(2).setCellRenderer(centerRenderer2); 

		   		DefaultTableCellRenderer centerRenderer3 = new DefaultTableCellRenderer();
centerRenderer3.setHorizontalAlignment(SwingConstants.CENTER);
 tb1.getColumnModel().getColumn(3).setCellRenderer(centerRenderer3); 

	 

DefaultTableCellRenderer centerRenderer4 = new DefaultTableCellRenderer();
centerRenderer4.setHorizontalAlignment(SwingConstants.CENTER);
tb1.getColumnModel().getColumn(4).setCellRenderer(centerRenderer4); 


		   		DefaultTableCellRenderer centerRenderer5 = new DefaultTableCellRenderer();
centerRenderer5.setHorizontalAlignment(SwingConstants.CENTER);
 tb1.getColumnModel().getColumn(5).setCellRenderer(centerRenderer5); 

	 
 
		
		
		 
		 
		
		 
		 
	 
		
		this.add(p1);
		this.add(p2);
		this.add(p3);
		 
		 
		  background.add(header);
		 add(background);
		setVisible(true);
   
   

	}
	
	
	 public void actionPerformed(ActionEvent ae)
		{   
		   
		  
		 
		  
		  
		  
		  
		  
		   if(ae.getSource()==b2)
		  {
			  
			  t3.setText("0");
			  t4.setText("0");
			  t5.setText("0");
			  t6.setText("0");
			  t7.setText("0");
			  
			  
			  
			  
			  
		  }
		  
		   else if(ae.getSource()==b4)
		  {  int numrowsy=tb1.getSelectedRow(); 
	         if(numrowsy>=0)
			 {    
	         String q1=new String();
			  String q2=new String();
			   String q3=new String();
			    String ap=new String();
				 String as=new String();
			     
				 
				 
				 
				 
				           
				//   ||  Integer.parseInt(t3.getText()) >20 || Integer.parseInt(t3.getText()) <0 
				 
				 
				 
 if(isParsable(t3.getText())==false ||  Integer.parseInt(t3.getText()) >20 || Integer.parseInt(t3.getText()) <0 || t3.getText().length()>2)
				 { t3.setText(row[numrowsy][1]); q1=t3.getText(); JOptionPane.showMessageDialog(null, "Only Input Integers (<=20) in Quiz 1"); 
			 } 
			   
			   else if  (isParsable(t3.getText())==true)
				 { q1=t3.getText();

			     } 
			 
			 
			 
 if(isParsable(t4.getText())==false ||  Integer.parseInt(t4.getText()) >20 || Integer.parseInt(t4.getText()) <0 || t4.getText().length()>2)
		 {t4.setText(row[numrowsy][2]);  q2=t4.getText();  JOptionPane.showMessageDialog(null, "Only Input Integers (<=20) in Quiz 2");

			    } 
				
				else if  (isParsable(t4.getText())==true)
				 { q2=t4.getText(); 

			    } 
			 
			 
				 
 if(isParsable(t5.getText())==false ||  Integer.parseInt(t5.getText()) >20 || Integer.parseInt(t5.getText()) <0 || t5.getText().length()>2)
		  { t5.setText(row[numrowsy][3]);  q3=t5.getText();  JOptionPane.showMessageDialog(null, "Only Input Integers (<=20) in Quiz 3");

			      }  
			  else if  (isParsable(t5.getText())==true)
				 { q3=t5.getText();  

			    } 
			  
				  
 if(isParsable(t6.getText())==false ||  Integer.parseInt(t6.getText()) >10 || Integer.parseInt(t6.getText())<0 || t6.getText().length()>2 )
		  {  t6.setText(row[numrowsy][4]); ap=t6.getText(); 
			   JOptionPane.showMessageDialog(null, "Only Input Integers (<=10) in Attendance/Performance");

			        }  
			   else if  (isParsable(t6.getText())==true)
				 { ap=t6.getText();  

			    } 
			    
				   
 if(isParsable(t7.getText())==false ||  Integer.parseInt(t7.getText()) >30 || Integer.parseInt(t7.getText()) <0 || t7.getText().length()>2)
			 { t7.setText(row[numrowsy][5]);  as=t7.getText();  
				JOptionPane.showMessageDialog(null, "Only Input Integers (<=30) in Assessment ");
			 	    } 
                   else if  (isParsable(t7.getText())==true)
			  	   { as=t7.getText();

			        } 
				 
				 
				   
				 
				   
				 
				 
				 
				 
				 
				 
				 
	 
			 
			  tb1.setValueAt(q1,numrowsy,1);
			 tb1.setValueAt(q2,numrowsy,2);
			 tb1.setValueAt(q3,numrowsy,3);
			 tb1.setValueAt(ap,numrowsy,4);
			 tb1.setValueAt(as,numrowsy,5);   } else{JOptionPane.showMessageDialog(null, "Select A Row First");}
		  }
		  
		  
		  else if(ae.getSource()==b5)
		  {
			  marksP er=new marksP();
			  this.setVisible(false);
			  er.setVisible(true);
			  
			  
		  }
		  
		  else if(ae.getSource()==b6)
		{ 
                     
				  
				  String ss[]=new String[5];
				  String q1[]=new String[5];
				  String q2[]=new String[5];
				  String q3[]=new String[5];
				  String ap[]=new String[5];
				  String as[]=new String[5];
				  
			     
				 
					 
				    ss[0]=tb1.getValueAt(0,0).toString();
					q1[0]=tb1.getValueAt(0,1).toString();
					q2[0]=tb1.getValueAt(0,2).toString();
					q3[0]=tb1.getValueAt(0,3).toString();
					ap[0]=tb1.getValueAt(0,4).toString();
					as[0]=tb1.getValueAt(0,5).toString();
				 
				 
				  
				  ss[1]=tb1.getValueAt(1,0).toString();
				  q1[1]=tb1.getValueAt(1,1).toString();
				  q2[1]=tb1.getValueAt(1,2).toString();
				  q3[1]=tb1.getValueAt(1,3).toString();
				  ap[1]=tb1.getValueAt(1,4).toString();
				  as[1]=tb1.getValueAt(1,5).toString();
				  
				  
				    
				    ss[2]=tb1.getValueAt(2,0).toString();
					q1[2]=tb1.getValueAt(2,1).toString();
					q2[2]=tb1.getValueAt(2,2).toString();
					q3[2]=tb1.getValueAt(2,3).toString();
					ap[2]=tb1.getValueAt(2,4).toString();
					as[2]=tb1.getValueAt(2,5).toString();
				 
				 
				  
				  ss[3]=tb1.getValueAt(3,0).toString();
				  q1[3]=tb1.getValueAt(3,1).toString();
				  q2[3]=tb1.getValueAt(3,2).toString();
				  q3[3]=tb1.getValueAt(3,3).toString();
				  ap[3]=tb1.getValueAt(3,4).toString();
				  as[3]=tb1.getValueAt(3,5).toString();
				  
				   
				  ss[4]=tb1.getValueAt(4,0).toString();
				  q1[4]=tb1.getValueAt(4,1).toString();
				  q2[4]=tb1.getValueAt(4,2).toString();
				  q3[4]=tb1.getValueAt(4,3).toString();
				  ap[4]=tb1.getValueAt(4,4).toString();
				  as[4]=tb1.getValueAt(4,5).toString();
				 
				  
		 
	 
	 
	 
	 
	 
	          	  int i=0,j=0,k=0;  
	                
	     
		  
			 String xD1[]=new String[5];
				 
			 	  xD1[0]=tripler(q1[0])+"-"+tripler(q2[0])+"-"+tripler(q3[0])+"-"+tripler(ap[0])+"-"+tripler(as[0]);
				    xD1[1]=tripler(q1[1])+"-"+tripler(q2[1])+"-"+tripler(q3[1])+"-"+tripler(ap[1])+"-"+tripler(as[1]);
				    xD1[2]=tripler(q1[2])+"-"+tripler(q2[2])+"-"+tripler(q3[2])+"-"+tripler(ap[2])+"-"+tripler(as[2]);
				     xD1[3]=tripler(q1[3])+"-"+tripler(q2[3])+"-"+tripler(q3[3])+"-"+tripler(ap[3])+"-"+tripler(as[3]);
					  xD1[4]=tripler(q1[4])+"-"+tripler(q2[4])+"-"+tripler(q3[4])+"-"+tripler(ap[4])+"-"+tripler(as[4]);
		//	 System.out.println();	 System.out.println(xD1); System.out.println();  
			
		 
		//	System.out.println(xD1[0]);
			
		//	System.out.println(xD1[1]);
			
		//	System.out.println(xD1[2]);
			
		//	System.out.println(xD1[3]);
			
		//	System.out.println(xD1[4]);
			 
			 
		 
			 
			 
			 
			
			       String aa[]=new String[100];
				   String bb[]=new String[100];
				   String cc[]=new String[100];
				   String dd[]=new String[100];
				   String ee[]=new String[100];
				   String ff[]=new String[100];
				   String gg[]=new String[100];
				   String hh[]=new String[100];
				   String ii[]=new String[100];
				   String jj[]=new String[100];
				   String kk[]=new String[100];
				   String ll[]=new String[100];
				   String mm[]=new String[100];
				  
			
			
			
			try{   File myFile=new File("allstudentsinfo3.txt");
					   Scanner m=new Scanner(myFile);
					   while(m.hasNextLine())
					   {  aa[i]=m.nextLine();
				          bb[i]=m.nextLine();
                          cc[i]=m.nextLine();
						  dd[i]=m.nextLine();
						  ee[i]=m.nextLine();
						  ff[i]=m.nextLine();
                          gg[i]=m.nextLine();
                          hh[i]=m.nextLine();
                          ii[i]=m.nextLine();
                          jj[i]=m.nextLine();
                          kk[i]=m.nextLine();
                          ll[i]=m.nextLine();
                          mm[i]=m.nextLine();						  
				     
						   i++;
						   
						   
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       } 
									   
									   
									   
				 
				 int t=0;
				 
				 while(t<=4)
				 { 
				 for(j=0; j<=i && aa[j]!=null && mm[j]!=null; j++)
				 {                              
			 
			 
			      if(dd[j].equalsIgnoreCase(ss[t]) && bb[j].equalsIgnoreCase(Name))
				  {
					  ee[j]=xD1[t]; break;
					  
					  
				  }		


                 else  if(ff[j].equalsIgnoreCase(ss[t]) && bb[j].equalsIgnoreCase(Name))
				  {
					  gg[j]=xD1[t]; break;
					  
					  
				  }		

                 else   if(hh[j].equalsIgnoreCase(ss[t]) && bb[j].equalsIgnoreCase(Name))
				  {
					  ii[j]=xD1[t]; break;
					  
					  
				  }		


                  else if(jj[j].equalsIgnoreCase(ss[t]) && bb[j].equalsIgnoreCase(Name))
				  {
					  kk[j]=xD1[t]; break;
					  
					  
				  }		


                   else if(ll[j].equalsIgnoreCase(ss[t]) && bb[j].equalsIgnoreCase(Name))
				  {
					  mm[j]=xD1[t]; break;
					  
					  
				  }						  
			 
			 
			 
			 
			 
			 
			 
			 
		} t++;	}				 
				 j=0;
				 
				 
				 
				 try{                          
														// Create file 
											FileWriter fstream = new FileWriter("allstudentsinfo3.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											 while(j<=i && aa[j]!=null && mm[j]!=null)
											 {
												 out.write(aa[j]+"\n");
												  out.write(bb[j]+"\n");
												   out.write(cc[j]+"\n");
												    out.write(dd[j]+"\n");
													 out.write(ee[j]+"\n");
													  out.write(ff[j]+"\n");
													   out.write(gg[j]+"\n");
													    out.write(hh[j]+"\n");
														 out.write(ii[j]+"\n");
														  out.write(jj[j]+"\n");
														   out.write(kk[j]+"\n");
														    out.write(ll[j]+"\n");
															 out.write(mm[j]+"\n");
												 
												 
												 
												 
												 ++j;
											 }
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 	

				 b6.setText("Successfully Published");
				 b6.setForeground(Color.green);
				 
				 
				 
		double gp1= cutCalcGradePoint(xD1[0]);
		double gp2= cutCalcGradePoint(xD1[1]);
		double gp3= cutCalcGradePoint(xD1[2]);
		double gp4= cutCalcGradePoint(xD1[3]);
	    double gp5= cutCalcGradePoint(xD1[4]);
		
		float cgpa=0.0f;
		
		
		 
		
		
		
		
		
		
		String nameXY[]=new String[1000];
		String idXY[]=new String[1000];
		String cgpaXY[]=new String[1000];
		
		i=0; j=0;
		
		try{   File myFile=new File("allstudentsinfo2.txt");
					   Scanner m=new Scanner(myFile);
					   
					   while(m.hasNextLine())
					   {  nameXY[i]=m.nextLine(); 
				          idXY[i]=m.nextLine(); 
                          cgpaXY[i]=m.nextLine();
						  					  
				     
						   i++;
						   
						   
					   }
					   m.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       } 
									   
				j=0;
				
			while(j<=i && nameXY[j]!=null && idXY[j]!=null && cgpaXY[j]!=null )
			{
				if(nameXY[j].equals(Name)   )
				{
					
					cgpa=Float.parseFloat(cgpaXY[j]);
				}
				
				
				
				
				j++;
			}				
									   
									   
				j=0;					   
			

			  if(gp1==0.0d || gp2==0.0d || gp3==0.0d || gp4==0.0d || gp5==0.0d)
		{cgpa=0.0f; }
	    
	    else
		{
			if(cgpa>0f)
			{cgpa=(float)(gp1+gp2+gp3+gp4+gp5+5*cgpa)/10;}
		    else{cgpa=(float)(gp1+gp2+gp3+gp4+gp5)/5; }
			
			
			
			
			
			if(cgpa>=4.0f){ cgpa=4.0f; }
			
		}						   
			
j=0;			
		
		  
		 
		 
		 
		 
		
		while(j<=i && nameXY[j]!=null && idXY[j]!=null && cgpaXY[j]!=null )
			{
				if(nameXY[j].equals(Name)   )
				{
					
					 cgpaXY[j]=String.valueOf(cgpa) ; 
				}
				
				
				
				
				j++;
			}
		
		j=0;
		
		
		 try{                          
														// Create file 
											FileWriter fstream = new FileWriter("allstudentsinfo2.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											 while(j<=i && nameXY[j]!=null && idXY[j]!=null && cgpaXY[j]!=null)
											 {
												 out.write(nameXY[j]+"\n");
												  out.write(idXY[j]+"\n");
												   out.write(cgpaXY[j]+"\n");
												    
												 
												 
												 
												 
												 ++j;
											 }
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 	
																						
																						i=0; j=0;
		
				 
				 
				 
				 
				 
				// ad
				 
				  
			 
			  
			  
			  
			  
		   
				
				  
				
			}
		  
		  
		  
		  
		  
		  
		  
		  }
		
	
	public static void main(String[] args)
 {
	addMarks pq=new addMarks(marksP.n);
	 
	 
	 
 }
 
 }
	