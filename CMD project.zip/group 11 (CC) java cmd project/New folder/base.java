import com.sun.jna.*;
import com.sun.jna.platform.win32.WinDef.*;
import com.sun.jna.platform.win32.WinNT.HANDLE;
import java.util.Scanner;
import java.io.*; 
import java.util.InputMismatchException;
 
 class student{ 
 static Scanner s=new Scanner(System.in);
 
 String sc[]=new String[5];
 int q1[]=new int[5];
  int q2[]=new int[5];
   int q3[]=new int[5];
   int ast[]=new int[5];
   int mt[]=new int[5];
   float CGPA;
   
   boolean oktoregister;
   
   int c1q1;
    int c1q2;
	 int c1q3;
	  int c1ap;
	   int c1as;
	   int c1tm;
	   
	   
	    int c2q1;
    int c2q2;
	 int c2q3;
	  int c2ap;
	   int c2as;
	    int c2tm;
	   
	    int c3q1;
    int c3q2;
	 int c3q3;
	  int c3ap;
	   int c3as;
	    int c3tm;
	   
	    int c4q1;
    int c4q2;
	 int c4q3;
	  int c4ap;
	   int c4as;
	    int c4tm;
		
		
	    int c5q1;
    int c5q2;
	 int c5q3;
	  int c5ap;
	   int c5as;
	    int c5tm;
		
   String grade1=new String();
    String grade2=new String();
	 String grade3=new String();
	  String grade4=new String();
	   String grade5=new String();
   
   
   String course[]=new String[5];
   
    String marksArray[]=new String[5];
   
   
   
   public static int cut(String s, int x, int y)
	{
		
		 String ss=s.substring(x-1,y);
		 int xx=Integer.parseInt(ss);
		 
		 return xx;
		
		
	}
   
   
   
   
   base bb=new base();
 String name, id, dept;
 int roll;
 
 student(){};
 student(String a,String b,String c,String d,String e, String f, String g, String h, int qq)
 { sc[0]=a;  sc[1]=b; sc[2]=c; sc[3]=d; sc[4]=e; this.name=f; this.id=g; this.dept=h; this.roll=qq; };
 
 
 
 void showInfo(String a, String b, String c, String d, String e)
 {
	 base.cls(); base.boxmaker();
	 base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,57); base.r(); System.out.print("YOUR INFORMATION ");  base.o();
 base.gotoxy(4,43);base.r(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
	 
	 base.gotoxy(7,43); base.r(); System.out.print("1. "); base.o(); System.out.print("Name : "); base.r(); System.out.print(a);  base.o();
	 
	  base.gotoxy(10,43); base.r(); System.out.print("2. "); base.o();System.out.print("ID : "); base.r();  System.out.print(b);  base.o();
	  
	   base.gotoxy(13,43); base.r(); System.out.print("3. "); base.o();System.out.print("Password : "); base.r();  System.out.print(c);  base.o();
	   
	    base.gotoxy(16,43); base.r(); System.out.print("4. "); base.o();System.out.print("Semester : "); base.r(); System.out.print(d);  base.o();
		
		 base.gotoxy(19,43); base.r(); System.out.print("5. "); base.o();System.out.print("CGPA : "); base.r(); System.out.print(e);  base.o();
	 
	 
	  base.gotoxy(24,36);  base.y(); System.out.print("Press any key to return : "); base.o(); Scanner s=new Scanner(System.in); String gt=s.nextLine();
	  
	   this.smenu();
	 
 }
 
   public   void smenu(){ String a,b,c;   
	base.cls(); base.boxmaker();
	boolean oktoregister=true;
	
	String aq=new String();
	String bq=new String();
	String cq=new String();
	String dq=new String();
	
	
	
	try {File sx=new File("loggedinuserinfo.txt");
	Scanner m2=new Scanner(sx);
	
	while(m2.hasNextLine())
	{
		
		aq=m2.nextLine();
		bq=m2.nextLine();
		cq=m2.nextLine();
		dq=m2.nextLine();
		
	 
	}m2.close();}  
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
			  	}
				
				
		String wq=new String();
		String wq2=new String();	




try {File sx=new File("rswitch.txt");
	Scanner m3=new Scanner(sx);
	
	while(m3.hasNextLine())
	{
		
		wq=m3.nextLine();
		wq2=m3.nextLine();
		 
		if(wq.equals(aq)){break;}
	 
	}m3.close();}  
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
			  	}






		
     		
				
				
				
		String eq=new String();
				String fq=new String();
		
		try {File sx2=new File("allstudentgrades.txt");
	Scanner m2=new Scanner(sx2);
	
	while(m2.hasNextLine())
	{
		
		eq=m2.nextLine();
		fq=m2.nextLine();
		
		if(eq.equals(aq)){ break; }
		 
		
	 
	}m2.close();}  
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}

    																					
																						
	 
	this.name=aq;
	this.id=bq;
	
	 	 
	
	 base.gotoxy(2,63); System.out.println(fq); 
	
	base.o(); String dd=new String();
  base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,57); base.r(); System.out.print("STUDENT PORTAL: ");  base.o();
 base.gotoxy(4,43);base.r(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");   
 base.gotoxy(7,52); base.r();System.out.print("1. "); base.o();System.out.print("Show Selected Courses : ");    
 base.gotoxy(10,52); base.r(); System.out.print("2. "); base.o();System.out.print("Show Result : ");  
 base.gotoxy(13,52);base.r(); System.out.print("3. "); base.o();System.out.print("Register Courses : ");
 base.gotoxy(16,52);base.r(); System.out.print("4. "); base.o();System.out.print("Show Account Info : ");   
 base.gotoxy(19,52);base.r();System.out.print("5. ");  base.o();System.out.print("Log Out : ");  
 
 base.gotoxy(22,39); base.r(); System.out.print("Choose any One : "); base.o();
  dd=s.nextLine();   
 
 if(dd.equals("1")){this.showsc(); }
 
 
 
 else if(dd.equals("2")){this.showMarks(); }
 
  else if(dd.equals("3")){   
  
  if(fq.equals("Not Graded"))
  { base.gotoxy(25,39); base.r(); System.out.print("You Have To Complete This Semester First  !!");  base.sleep(3000);
  base.o(); base.cls(); student bb=new student(); bb.smenu();  }
  
  else if(wq2.equals("0")){ base.gotoxy(25,39); base.r(); System.out.print("Results of this semester have to be published first!!");  base.sleep(3000);
  base.o(); base.cls(); student bb=new student(); bb.smenu();  }

  else{  this.registry(aq,bq,cq,dq);  }


  }
  
   else if(dd.equals("4")){this.showInfo(aq,bq,cq,dq,fq); }
   
   else if(dd.equals("5")){  try{	FileWriter f=new FileWriter("loginstatus.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("0");
			bc.close(); }
			catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 } base.cls();   base bb=new base(); bb.menu();  }
									 
  else  { base.cls(); student bb=new student(); bb.smenu();   }
 
 }
 
 
 
 
 
 
 
 

 
 void registry(String name, String id, String password, String semesterCount){  Scanner course = new Scanner(System.in);
base.cls(); base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,57); base.r(); System.out.print("COURSE REGISTRATION: ");  base.o();        base.gotoxy(3,87); base.r(); System.out.print("Press 0 to return");
 base.gotoxy(4,43);base.r(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");
  int h=0;
  int I=0,J=0;
  
  this.name=name;
  String blankArray=new String("000-000-000-000-000");

 int X=Integer.parseInt(semesterCount);
 
 String a1[]=new String[1000];
  String a2[]=new String[1000];
   String a3[]=new String[1000];
    String a4[]=new String[1000];
	 String a5[]=new String[1000];
	  String a6[]=new String[1000];
	   String a7[]=new String[1000];
	   
	   
	   
	   String  A1[]=new String[1000];
String  A2[]=new String[1000];
String  A3[]=new String[1000];
String Ac1[]=new String[1000];
String Am1[]=new String[1000];
String Ac2[]=new String[1000];
String Am2[]=new String[1000];
String Ac3[]=new String[1000];
String Am3[]=new String[1000];
String Ac4[]=new String[1000];
String Am4[]=new String[1000];
String Ac5[]=new String[1000];
String Am5[]=new String[1000];

 try{
		File x=new File("studentsandcourses.txt");
	
	Scanner mx=new Scanner(x);
	
	while(mx.hasNextLine())
	{
		A1[I]=mx.nextLine();
		A2[I]=mx.nextLine();
		A3[I]=mx.nextLine();
		 Ac1[I]=mx.nextLine();
		Am1[I]=mx.nextLine();
		Ac2[I]=mx.nextLine();
		Am2[I]=mx.nextLine();
		 Ac3[I]=mx.nextLine();
		Am3[I]=mx.nextLine();
		 Ac4[I]=mx.nextLine();
		Am4[I]=mx.nextLine();
		 Ac5[I]=mx.nextLine();
		Am5[I]=mx.nextLine();
		
		I++;
		
		
		
	} mx.close(); }
	
	catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       } 
									

I=0; J=0;									
									   
	   
	   
	  try {File sx=new File("allcourses.txt");
	Scanner m2=new Scanner(sx);
	
	while(m2.hasNextLine())
	{
		
		a1[I]=m2.nextLine();
		a2[I]=m2.nextLine();
		a3[I]=m2.nextLine();
		a4[I]=m2.nextLine();
        a5[I]=m2.nextLine();
		 a6[I]=m2.nextLine();
	     a7[I]=m2.nextLine();
	      
		I++;
	 
	}m2.close();}  
	
	
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 
	   
	   
	   
  int xg=0;
// System.out.println("How many semesters do you want to study??");
 int sc;//=course.nextInt();
 sc=1;
 int sk=0;
  int i=0; int j=0;
 String xc[]=new String [50];
 int k[]=new int [50];
   
  System.out.println();
 while(sk<sc) { System.out.println();
 
 
 base.gotoxy(6,57);  base.g(); System.out.println("Semester "+ (X+1)+" Courses : "); base.o(); System.out.println();
 base.gotoxy(7,42);  base.r(); System.out.println("-----------------------------------------------"); base.o();
 
  if(a1[X-1]==null || a7[X-1]==null)
  {base.gotoxy(9,32); base.r(); System.out.print("No More Courses are Available for you, Press any key to return : "); base.o(); String gty=course.nextLine(); this.smenu();}
  
  
 base.gotoxy(9,36); base.r(); System.out.print("1. "); base.o(); System.out.print(a1[X-1]);  
 
 base.gotoxy(12,36); base.r(); System.out.print("2. "); base.o(); System.out.print(a2[X-1]);  
 

 base.gotoxy(15,36); base.r(); System.out.print("3. "); base.o(); System.out.print(a3[X-1]);  
 
 base.gotoxy(18,36); base.r(); System.out.print("4. "); base.o(); System.out.print(a4[X-1]);  
 
 
 base.gotoxy(9,80); base.r(); System.out.print("5. ");  base.o(); System.out.print(a5[X-1]);  

  base.gotoxy(12,80);base.r(); System.out.print("6. "); base.o(); System.out.print(a6[X-1]);  

 base.gotoxy(15,80); base.r(); System.out.print("7. "); base.o(); System.out.print(a7[X-1]);  


 

int xG[]=new int[6];

int iz=0;

base.gotoxy(21,17);
System.out.println(); System.out.println();
 
 for(i=0;i<5;i++)
 {
	 System.out.print("Choose Course Number (Any 5 of them):");
	 try {xg=course.nextInt();}
	 catch(InputMismatchException e)
	 {  base.r(); System.out.print("Invalid input, Try again"); base.o(); base.sleep(3000); this.smenu();}
	 
	  xG[iz]=xg;
	 iz++;
	 
	 if(xg>7 || xg<0){ base.r(); System.out.print("Input cannot exceed 7, Try again"); base.o(); base.sleep(3000); this.smenu(); }
	 else if(xg==0){     this.smenu(); }
	 
	 
	  
	 
	 else{  
	 k[i+sk*5] =xg;
	 if(k[i+sk*5]==3)
	 
	 {
		 xc[i+sk*5]= a3[X-1];
		base.g(); System.out.println(xc[i] );  base.o();
	 }
	 else if(k[i+sk*5]==1)
	 {xc[i+sk*5]= a1[X-1];
		base.g(); System.out.println(xc[i] ); System.out.println(); base.o();
	 }
	 
	  else if(k[i+sk*5]==2)
	 {xc[i+sk*5]= a2[X-1]; ;
		base.g(); System.out.println(xc[i] ); System.out.println(); base.o();
	 }
	 
	  else if(k[i+sk*5]==5)
	 {xc[i+sk*5]= a5[X-1]; 
		base.g(); System.out.println(xc[i] ); System.out.println(); base.o();
	 }
	 
	  
	 else if(k[i+sk*5]==4)
	 {xc[i+sk*5]= a4[X-1];
		base.g(); System.out.println(xc[i] ); System.out.println(); base.o();
	 }
	 
	 else if(k[i+sk*5]==6)
	 {xc[i+sk*5]= a6[X-1];
		base.g(); System.out.println(xc[i] ); System.out.println(); base.o();
	 }
	 
	 else if(k[i+sk*5]==7)
	 {xc[i+sk*5]= a7[X-1];
		base.g(); System.out.println(xc[i] ); System.out.println(); base.o();
	 }
   
	 else
	 {
		base.r(); System.out.println("The course number is incorret!!!!!"); base.o();
 } }
  }  sk++; 

  }
 System.out.println();
 
 
 i=0;  j=0;
 
 boolean repeat=false;
 
 for(i=0; i<=4; i++)
 {
	 
	 
	 if(repeat==true){ break; }
	 
	 
	for(j=0; j<=4; j++)
 {
	 
	 if(j==i) {continue;}
else{
		 if(xc[j].equals(xc[i])) { repeat=true; break; }
		 
		 
		 
		 
    }
	 
 
 } 
	 
	 
	 
	 
 }
 
 base.cls(); base.boxmaker(); base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,51); base.r(); System.out.print("YOUR REGISTERED COURSES ARE :: ");  base.o();
 base.gotoxy(4,43);base.r(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");
  int c3=1;
  int c4=0;
  
 for(i=0;i<5*sk;i++)
 { 
     System.out.println();
	{base.r(); 
	
	base.gotoxy(7+3*i, 57); System.out.print("Course no."+(c4+1)+": "); base.o(); System.out.println(xc[i]);  
	 
	System.out.println();} c4++;
	if(i==(5*sk-1)){break;}
	if(c4==5){c3=c3+1; c4=0;       } 
 }  
  
  
  
  if(repeat==true) 
  {base.gotoxy(24,40);	base.r(); System.out.print("You have selected the same course multiple times, TRY AGAIN : ");  base.o(); 

 base.sleep(5000); this.smenu(); } 
 
 
 String t1=new String(); base.gotoxy(25,40);	base.r(); System.out.print("Choose : 1. Confirm Registration       2. Cancel  : ");  
 
 
 
 
 t1=s.nextLine();  
 
 boolean rok=false;
 
 if(t1.equals("1")){ rok=true;}
 if(rok==true)
 {
		J=0;
		
		while(J<=I && A1[J]!=null)
        {
			
			if(A1[J].equals(name) && A2[J].equals(id) && A3[J].equals(password) )
				
				{
					Ac1[J]=xc[0];
					Am1[J]=blankArray;
					
					Ac2[J]=xc[1];
					Am2[J]=blankArray;
					
					Ac3[J]=xc[2];
					Am3[J]=blankArray;
					
					Ac4[J]=xc[3];
					Am4[J]=blankArray;
					
					Ac5[J]=xc[4];
					Am5[J]=blankArray;
					
					
					
					
					
					
				}
			
			J++;
			
		}
		
		J=0;
		
		try{
														// Create file 
											FileWriter fstream = new FileWriter("studentsandcourses.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											 while(J<=I && A1[J]!=null)
											 {
												out.write(A1[J]+"\n"); 
												out.write(A2[J]+"\n") ;
												out.write(A3[J]+"\n") ;
												out.write(Ac1[J]+"\n"); 
												out.write(Am1[J]+"\n"); 
												out.write(Ac2[J]+"\n"); 
												out.write(Am2[J]+"\n"); 
												out.write(Ac3[J]+"\n"); 
												out.write(Am3[J]+"\n"); 
												out.write(Ac4[J]+"\n"); 
												out.write(Am4[J]+"\n"); 
												out.write(Ac5[J]+"\n") ;
												out.write(Am5[J]+"\n"); 
												 
												 
												 
												 J++;
												 
											 }
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}
		
		X=X+1;
		
		semesterCount=Integer.toString(X);
		
		
		try{
														// Create file 
											FileWriter fstream = new FileWriter("loggedinuserinfo.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											  
												out.write(name+"\n"); 
												out.write(id+"\n") ;
												out.write(password+"\n") ;
												out.write(semesterCount+"\n"); 
												 
												 
												 
												 
												  
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}
		
		
		
		
		
		String q1[]=new String[1000];
		String q2[]=new String[1000];
		String q3[]=new String[1000];
		String q4[]=new String[1000];
		
		
		I=0; J=0;

      try {File sx=new File("allstudentsinfo.txt");
	Scanner m2=new Scanner(sx);
	
	while(m2.hasNextLine())
	{
		
		q1[I]=m2.nextLine();
		q2[I]=m2.nextLine();
		q3[I]=m2.nextLine();
		q4[I]=m2.nextLine();
		
		if(q1[I].equals(name) && q2[I].equals(id) && q3[I].equals(password))
		{
			q4[I]=semesterCount;
			
		}
       
		I++;
	 
	}m2.close();}  
	
	
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}



  try{
														// Create file 
											FileWriter fstream = new FileWriter("allstudentsinfo.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											  
											  while(J<=I && q1[J]!=null)
											  {	out.write(q1[J]+"\n"); 
												out.write(q2[J]+"\n") ;
												out.write(q3[J]+"\n") ;
												out.write(q4[J]+"\n"); 
												 
												 
												J++; 
											  }
												  
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}
		
		
		 
		 
		
I=0; J=0;

String wq[]=new String[1000];
		String wq2[]=new String[1000];	




try {File sx=new File("rswitch.txt");
	Scanner m3=new Scanner(sx);
	
	while(m3.hasNextLine())
	{
		
		wq[I]=m3.nextLine();
		wq2[I]=m3.nextLine();
		 
		 I++;
	 
	}m3.close();}  
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
			  	}




    while(J<=I && wq[J]!=null)
	{
		if(wq[J].equals(this.name) || wq[J].equals(name) )
		{
			
		  wq2[J]="0";	
			
			
			
		}
		
		
		J++;
		
	}

J=0;

try{
														// Create file 
											FileWriter fstream = new FileWriter("rswitch.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											 while(J<=I && wq[J]!=null)
											 {
												out.write(wq[J]+"\n"); 
												out.write(wq2[J]+"\n") ;
												 
												 
												 
												 
												 J++;
												 
											 }
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}	
																						
																						
																						 
	base.o();	this.smenu();
		
		}
		
		else
{ base.o(); this.smenu(); }
 
 
}
 
 void showMarks()
 { 
 	String aq=new String();
			String bq=new String(); int u=0;
 
 
  String az[]=new String[1000];
	String bz[]=new String[1000];
	String cz[]=new String[1000];
	String dz[]=new String[1000];
	String ez[]=new String[1000];
	String fz[]=new String[1000];
	String gz[]=new String[1000];
	String hz[]=new String[1000];
	String iz[]=new String[1000];
	String jz[]=new String[1000];
	String kz[]=new String[1000];
	String lz[]=new String[1000];
	String mz[]=new String[1000]; 

  int I=0,J=0;















 base.cls();   base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,55); base.b(); System.out.print("YOUR MARK SHEET ");  base.o();
 base.gotoxy(4,43);base.b(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  base.gotoxy(5,0);
	     { 

         
        String fileName = "tablem.txt";

        
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("                  "+line);
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
    }
	
	
	 
	
	  
	
	
	try{
		File x=new File("studentsandcourses.txt");
	
	Scanner mx=new Scanner(x);
	
	while(mx.hasNextLine())
	{
		az[I]=mx.nextLine();
		bz[I]=mx.nextLine();
		cz[I]=mx.nextLine();
		 dz[I]=mx.nextLine();
		ez[I]=mx.nextLine();
		 fz[I]=mx.nextLine();
		gz[I]=mx.nextLine();
		 hz[I]=mx.nextLine();
		iz[I]=mx.nextLine();
		 jz[I]=mx.nextLine();
		kz[I]=mx.nextLine();
		 lz[I]=mx.nextLine();
		mz[I]=mx.nextLine();
		
		I++;
		
		
		
	} mx.close(); }
	
	catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
									   
			while(J<I)
			{
				if(az[J].equals(this.name) && bz[J].equals(this.id))
				{
					
					this.course[0]=dz[J];
         					
					this.course[1]=fz[J];
					this.course[2]=hz[J];
					this.course[3]=jz[J];
					this.course[4]=lz[J];
					
					
					
					this.marksArray[0]=ez[J];
					this.marksArray[1]=gz[J];
					this.marksArray[2]=iz[J];
					this.marksArray[3]=kz[J];
					this.marksArray[4]=mz[J];
					
					break;
					
				}
				
				
			 
				
				
				
				J++;
			}
	
	
	     
	
	    this.c1q1=cut(this.marksArray[0], 1, 3);
		this.c1q2=cut(this.marksArray[0], 5, 7);
		this.c1q3=cut(this.marksArray[0], 9, 11);
		this.c1ap=cut(this.marksArray[0], 13, 15);
		this.c1as=cut(this.marksArray[0], 17, 19);
		
		
		this.c2q1=cut(this.marksArray[1], 1, 3);
		this.c2q2=cut(this.marksArray[1], 5, 7);
		this.c2q3=cut(this.marksArray[1], 9, 11);
		this.c2ap=cut(this.marksArray[1], 13, 15);
		this.c2as=cut(this.marksArray[1], 17, 19);
	
	
	
		this.c3q1=cut(this.marksArray[2], 1, 3);
		this.c3q2=cut(this.marksArray[2], 5, 7);
		this.c3q3=cut(this.marksArray[2], 9, 11);
		this.c3ap=cut(this.marksArray[2], 13, 15);
		this.c3as=cut(this.marksArray[2], 17, 19);
	
	
	
		this.c4q1=cut(this.marksArray[3], 1, 3);
		this.c4q2=cut(this.marksArray[3], 5, 7);
		this.c4q3=cut(this.marksArray[3], 9, 11);
		this.c4ap=cut(this.marksArray[3], 13, 15);
		this.c4as=cut(this.marksArray[3], 17, 19);
	
	
		this.c5q1=cut(this.marksArray[4], 1, 3);
		this.c5q2=cut(this.marksArray[4], 5, 7);
		this.c5q3=cut(this.marksArray[4], 9, 11);
		this.c5ap=cut(this.marksArray[4], 13, 15);
		this.c5as=cut(this.marksArray[4], 17, 19);
	
	    this.c1tm=this.c1q1+this.c1q2+this.c1q3+this.c1ap+this.c1as;
		
		 this.c2tm=this.c2q1+this.c2q2+this.c2q3+this.c1ap+this.c2as;
		 
		  this.c3tm=this.c3q1+this.c3q2+this.c3q3+this.c3ap+this.c3as;
		  
		   this.c4tm=this.c4q1+this.c4q2+this.c4q3+this.c4ap+this.c4as;
		   
		    this.c5tm=this.c5q1+this.c5q2+this.c5q3+this.c5ap+this.c5as;
			
		 
			
			try {File sx=new File("allstudentgrades.txt");
	Scanner m2=new Scanner(sx);
	
	while(m2.hasNextLine())
	{
		
		aq=m2.nextLine();
		bq=m2.nextLine();
		 
		if(aq.equalsIgnoreCase(this.name)){break;}
	 
	}}
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}
	 
			
		boolean graded=false;	 
			 
			
			
			
			
			
			 if(bq.equalsIgnoreCase("Not Graded")) 
			 {  this.grade1="";
                 this.grade2="";
					this.grade3="";
						this.grade4="";
							this.grade5=""; 
			   }
			   
			   
			else
			{  this.grade1=grader(this.c1tm);
			   this.grade2=grader(this.c2tm);
			    this.grade3=grader(this.c3tm);
				 this.grade4=grader(this.c4tm);
			this.grade5=grader(this.c5tm); }
			
			 
	if(bq.equals("Not Graded")){graded=false;}		 
	else{graded=true;}	
	
	
if(bq!="Not Graded")
{ if(grade1.equals("F") || grade2.equals("F") || grade3.equals("F")  || grade4.equals("F") || grade5.equals("F") )
 {
	 
	 this.CGPA=0.0f;
	 
	 
 }
 else
 {
	  int qg=this.c1tm+this.c2tm+this.c3tm+this.c4tm+this.c5tm;
	  
	  this.CGPA=9*qg/10;
	  
	  if(this.CGPA>4f){ this.CGPA=4f;  }
	 
	 
	 
}}
 
	
	base.gotoxy(9,20); base.g(); System.out.print(course[0]); base.o();
	
	base.gotoxy(12,20); base.g(); System.out.print(course[1]); base.o();
	
	base.gotoxy(15,20); base.g(); System.out.print(course[2]); base.o();
	
	base.gotoxy(18,20); base.g(); System.out.print(course[3]); base.o();
	
	base.gotoxy(21,20); base.g(); System.out.print(course[4]); base.o();
	
	
	base.gotoxy(9,47); base.r(); System.out.print(c1q1); base.o();
	base.gotoxy(9,57); base.g(); System.out.print(c1q2); base.o();
	base.gotoxy(9,67); base.r(); System.out.print(c1q3); base.o();
	base.gotoxy(9,77); base.g(); System.out.print(c1ap); base.o();
	base.gotoxy(9,91); base.r(); System.out.print(c1as); base.o();
	base.gotoxy(9,103); base.g(); System.out.print(c1tm); base.o();
	base.gotoxy(9,114); base.r(); System.out.print(grade1); base.o();	
	
	base.gotoxy(12,47); base.r(); System.out.print(c2q1); base.o();
	base.gotoxy(12,57); base.g(); System.out.print(c2q2); base.o();
	base.gotoxy(12,67); base.r(); System.out.print(c2q3); base.o();
	base.gotoxy(12,77); base.g(); System.out.print(c2ap); base.o();
	base.gotoxy(12,91); base.r(); System.out.print(c2as); base.o();
	base.gotoxy(12,103); base.g(); System.out.print(c2tm); base.o();	
	base.gotoxy(12,114); base.r(); System.out.print(grade2); base.o();
	
	base.gotoxy(15,47); base.r(); System.out.print(c3q1); base.o();
	base.gotoxy(15,57); base.g(); System.out.print(c3q2); base.o();
	base.gotoxy(15,67); base.r(); System.out.print(c3q3); base.o();
	base.gotoxy(15,77); base.g(); System.out.print(c3ap); base.o();
	base.gotoxy(15,91); base.r(); System.out.print(c3as); base.o();
	base.gotoxy(15,103); base.g();  System.out.print(c3tm); base.o();
	base.gotoxy(15,114); base.r(); System.out.print(grade3); base.o();	
	
	base.gotoxy(18,47); base.r(); System.out.print(c4q1); base.o();
	base.gotoxy(18,57); base.g(); System.out.print(c4q2); base.o();
	base.gotoxy(18,67); base.r(); System.out.print(c4q3); base.o();
	base.gotoxy(18,77); base.g(); System.out.print(c4ap); base.o();
	base.gotoxy(18,91); base.r(); System.out.print(c4as); base.o();
	base.gotoxy(18,103); base.g(); System.out.print(c4tm); base.o();
	base.gotoxy(18,114); base.r(); System.out.print(grade4); base.o();
	
	base.gotoxy(21,47); base.r(); System.out.print(c5q1); base.o();
	base.gotoxy(21,57); base.g(); System.out.print(c5q2); base.o();
	base.gotoxy(21,67); base.r(); System.out.print(c5q3); base.o();
	base.gotoxy(21,77); base.g(); System.out.print(c5ap); base.o();
	base.gotoxy(21,91); base.r(); System.out.print(c5as); base.o();
	base.gotoxy(21,103); base.g(); System.out.print(c5tm); base.o();
	base.gotoxy(21,114); base.r(); System.out.print(grade5); base.o();
	
	
	
	String eq=new String();
	String fq=new String();
	
	 try {File sx2=new File("allstudentgrades.txt");
	Scanner m2=new Scanner(sx2);
	
	while(m2.hasNextLine())
	{
		
		eq=m2.nextLine();
		fq=m2.nextLine();
		
		if(eq.equals(this.name)){break; }
		 
		
	 
	}m2.close();}  
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}
	
	 
	
	 
	 
	//this.CGPA= Float.valueOf(fq);
	
	
	
	
	 
	
	
	 { base.gotoxy(24,59);  System.out.print("CGPA : "+fq);}
	base.gotoxy(26,53);	base.b(); System.out.print("Enter Any Key to Return :  "); base.o();  String gt=s.nextLine();  this.smenu();
	 
  
 }
    
void showsc() 
{   String az[]=new String[1000];
	String bz[]=new String[1000];
	String cz[]=new String[1000];
	String dz[]=new String[1000];
	String ez[]=new String[1000];
	String fz[]=new String[1000];
	String gz[]=new String[1000];
	String hz[]=new String[1000];
	String iz[]=new String[1000];
	String jz[]=new String[1000];
	String kz[]=new String[1000];
	String lz[]=new String[1000];
	String mz[]=new String[1000]; 

  int I=0,J=0;




base.cls();  
  base.gotoxy(2,43); base.y(); System.out.print(":::::::::::::::::::::::::::::::::::::::::"); base.o(); 
 base.gotoxy(3,57); base.r(); System.out.print("Selected Courses: ");  base.o();
 base.gotoxy(4,43);base.y();   System.out.print(":::::::::::::::::::::::::::::::::::::::::"); base.o();
int k=0;
 
     
	   File file = new File("C:\\Users\\Asus\\Desktop\\Important\\table.txt"); 
  
{  System.out.println();

        // The name of the file to open.
        String fileName = "table.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
               System.out.println("              "+line);  
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
    }
	
	 
	
	
	try{
		File x=new File("studentsandcourses.txt");
	
	Scanner mx=new Scanner(x);
	
	while(mx.hasNextLine())
	{
		az[I]=mx.nextLine();
		bz[I]=mx.nextLine();
		cz[I]=mx.nextLine();
		 dz[I]=mx.nextLine();
		ez[I]=mx.nextLine();
		 fz[I]=mx.nextLine();
		gz[I]=mx.nextLine();
		 hz[I]=mx.nextLine();
		iz[I]=mx.nextLine();
		 jz[I]=mx.nextLine();
		kz[I]=mx.nextLine();
		 lz[I]=mx.nextLine();
		mz[I]=mx.nextLine();
		
		I++;
		
		
		
	} mx.close(); }
	
	catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
									   
			while(J<I)
			{
				if(az[J].equals(this.name) && bz[J].equals(this.id))
				{
					
					this.course[0]=dz[J];  
					this.course[1]=fz[J];
					this.course[2]=hz[J];
					this.course[3]=jz[J];
					this.course[4]=lz[J];
					
					
					this.marksArray[0]=ez[J];
					this.marksArray[1]=gz[J];
					this.marksArray[2]=iz[J];
					this.marksArray[3]=kz[J];
					this.marksArray[4]=mz[J];
					
					
					
					break;
					
				}
				
				
				
				
				
				
				
				
				
				J++;
			}				
									   
									   
									   
	
base.gotoxy(6,18);	base.r(); System.out.print(course[4]);  base.o();
base.gotoxy(10,18);	base.r(); System.out.print(course[0]); base.o();
base.gotoxy(14,18);	base.r();System.out.print(course[2]); base.o();
base.gotoxy(18,18);	base.r();System.out.print(course[3]); base.o();
base.gotoxy(22,18);	base.r();System.out.print(course[1]); base.o();
	
base.gotoxy(6,55);	base.r(); System.out.print("Sunday(8:00am--9:30pm)");  base.o();
base.gotoxy(7,55);	base.y(); System.out.print("Tuesday(8:00am--9:30pm)");  base.o();
base.gotoxy(10,55);	base.r(); System.out.print("Sunday(11:00am--2:00pm)");  base.o();
base.gotoxy(11,55);	base.y(); System.out.print("Monday(12:30pm--2:00pm)");  base.o();
base.gotoxy(12,55);	base.r(); System.out.print("Wednesday(12:30pm--2:00pm)");  base.o();

base.gotoxy(14,55);	base.r(); System.out.print("Monday(8:00am--11:00pm)");  base.o();
base.gotoxy(15,55);	base.y(); System.out.print("Monday(2:00pm--3:30pm)");  base.o();
base.gotoxy(16,55);	base.r(); System.out.print("Wednesday(2:00pm--3:30pm)");  base.o();


base.gotoxy(18,55);	base.r(); System.out.print("Tuesday(11:30am--2:00pm)");  base.o();
base.gotoxy(22,55);	base.r(); System.out.print("Tuesday(2:00pm--3:30pm)");  base.o();
base.gotoxy(23,55);	base.y(); System.out.print("Sunday(2:00pm--3:30pm)");  base.o();
	
String t1=new String();	base.gotoxy(30,55);	base.r(); System.out.print("Press Any Key to return : ");  t1=s.nextLine(); base.o(); smenu();
	
	
  } 
	  
	
String grader(int marks)
{ 
if(marks>=90 && marks<=100) {return "A+";}
else if(marks>=85 && marks<=89) {return "A";}
else if(marks>=80 && marks<=84) {return "B+";}
else if(marks>=75 && marks<=79) {return "B";}
else if(marks>=70 && marks<=74) {return "C+";}
else if(marks>=65 && marks<=69) {return "C";}
else if(marks>=60 && marks<=64) {return "D+";}
else if(marks>=50 && marks<=59) {return "D";}
else if(marks<50 ) {return "F";}
	
	
	return "0";
	
	
 }	}
	
	
	
	
class teacher
{   static Scanner s=new Scanner(System.in);
	 boolean ax;
	boolean bx;
	boolean cx;
	 
	 public static int cut(String s, int x, int y)
	{
		
		 String ss=s.substring(x-1,y);
		 int xx=Integer.parseInt(ss);
		 
		 return xx;
		
		
	}
	 
	 
	void tmenu()
	{    
		int b,c;   String a=new String();
	base.cls(); base.boxmaker2();
  base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,57); base.b(); System.out.print("Faculty PORTAL: ");  base.o();
 base.gotoxy(4,43);base.b(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");   
 base.gotoxy(7,52); base.b();System.out.print("1. "); base.o();System.out.print("Add Marks : "); 
  base.gotoxy(10,52); base.b(); System.out.print("2. "); base.o();System.out.print("View Results : ");  

 base.gotoxy(13,52); base.b(); System.out.print("3. "); base.o();System.out.print("Log Out : ");  
 
 
 base.gotoxy(17,46);  System.out.print("Choose Any One :  ");  a=s.nextLine();
   
 
		if(a.equals("1")){this.addMarks();}
		
		else if(a.equals("3"))
		
		{
             try{	FileWriter f=new FileWriter("loginstatus.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("0");
			bc.close(); }
			catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 }
  
			base bb=new base(); bb.menu();}
		
		else if(a.equals("2")){ this.tViewMarks();}
		
		 else{base.cls(); teacher bb=new teacher(); bb.tmenu(); }
 
		
		
	}
	static String grader(int marks)
{ 
if(marks>=90 && marks<=100) {return "A+";}
else if(marks>=85 && marks<=89) {return "A";}
else if(marks>=80 && marks<=84) {return "B+";}
else if(marks>=75 && marks<=79) {return "B";}
else if(marks>=70 && marks<=74) {return "C+";}
else if(marks>=65 && marks<=69) {return "C";}
else if(marks>=60 && marks<=64) {return "D+";}
else if(marks>=50 && marks<=59) {return "D";}
else if(marks<50 ) {return "F";}
	
	
	return "0";
	
	
 }
 
 static String tripler(int a, int b, int c, int d, int e)
 {
	 String as=new String();
	  String bs=new String();
	   String cs=new String();
	    String ds=new String();
		 String es=new String();
		 
		 as=Integer.toString(a);
		 bs=Integer.toString(b);
		 cs=Integer.toString(c);
		 ds=Integer.toString(d);
		 es=Integer.toString(e);
	 
	 if(as.length()==1){as="00"+as;}
	 else if(as.length()==2){as="0"+as;}
	  else if(as.length()==3){as=as;}
	  
	   if(bs.length()==1){bs="00"+bs;}
	 else if(bs.length()==2){bs="0"+bs;}
	  else if(bs.length()==3){bs=bs;}
	  
	   if(cs.length()==1){cs="00"+cs;}
	 else if(cs.length()==2){cs="0"+cs;}
	  else if(cs.length()==3){cs=cs;}
	  
	   if(ds.length()==1){ds="00"+ds;}
	 else if(ds.length()==2){ds="0"+ds;}
	  else if(ds.length()==3){ds=ds;}
	  
	   if(es.length()==1){es="00"+es;}
	 else if(es.length()==2){es="0"+es;}
	  else if(es.length()==3){es=es;}
	
	 String fin=new String();
	 fin=as+"-"+bs+"-"+cs+"-"+ds+"-"+es;
	 
	 return fin;
	 
 }
	
  void tViewMarks()
	{
		 Scanner s=new Scanner(System.in);
		 String ax[]=new String[1000];
		 	 String bx[]=new String[1000]; int i=0,j=0;
		
		int a,b,c;   
	base.cls(); base.boxmaker();
  base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,57); base.r(); System.out.print("Student Grades: ");  base.o();
 base.gotoxy(4,43);base.b(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");   
 
 
 	try{   File myFilex=new File("allstudentgrades.txt");
					   Scanner m1=new Scanner(myFilex); System.out.println();
					   while(m1.hasNextLine())
					   {  
				            
						 
				           ax[i]=m1.nextLine(); base.gotoxy(11+2*i,50);   System.out.print(i+1+".  "+ax[i]+" ----- CGPA : ");  
						   bx[i]=m1.nextLine(); if(bx[i].equals("Not Graded") || bx[i].equals("0.0")){base.r(); System.out.println(bx[i]); base.o();}
						   else{ base.g(); System.out.println(bx[i]); base.o();}
						    
                                System.out.println();
						   i++;
				         
					   }
					   m1.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
			 	 
			 
			 
			 
			 base.gotoxy(6,53); System.out.print("Choose Student to view marks (0 to return) : "); int p=0; 
			 
			 try {p=s.nextInt(); }
			 catch(InputMismatchException e)
	         {  base.r();  base.gotoxy(7,53); System.out.print("Invalid input, Try again"); base.o(); base.sleep(3000); this.tViewMarks(); }	
			 
			 
			 if(p==0){this.tmenu();}
			 
			 else if(p>i || p<0){ base.gotoxy(7,53); base.r(); System.out.print("Choose a maximum value of "+i); base.o(); base.sleep(3000);    this.tViewMarks();}
			 
			  else if(i==0){ base.gotoxy(7,53); base.r(); System.out.print("No students have been added "); base.o(); base.sleep(3000);    this.tmenu();}
			 
			 p=p-1;  
			 
			 
			 
			 if(bx[p].equals("Not Graded"))
			 {base.gotoxy(8,53); base.r(); System.out.print("His/Her marks haven't been added yet" ); base.o(); base.sleep(2000); 
			 this.tmenu();}
			 
			 
			   else
			 {base.gotoxy(8,53); base.g(); System.out.print("You have selected "+ax[p] ); base.o(); base.sleep(1500); 
			 this.tViewMarks2(ax[p]);}
			 
			 
		 }


  void tViewMarks2( String sh)
  { 
 	String aq=new String();
			String bq=new String(); int u=0;
 
 
 float CGPA;
   
   int c1q1;
    int c1q2;
	 int c1q3;
	  int c1ap;
	   int c1as;
	   int c1tm;
	   
	   
	    int c2q1;
    int c2q2;
	 int c2q3;
	  int c2ap;
	   int c2as;
	    int c2tm;
	   
	    int c3q1;
    int c3q2;
	 int c3q3;
	  int c3ap;
	   int c3as;
	    int c3tm;
	   
	    int c4q1;
    int c4q2;
	 int c4q3;
	  int c4ap;
	   int c4as;
	    int c4tm;
		
		
	    int c5q1;
    int c5q2;
	 int c5q3;
	  int c5ap;
	   int c5as;
	    int c5tm;
		
   String grade1=new String();
    String grade2=new String();
	 String grade3=new String();
	  String grade4=new String();
	   String grade5=new String();
   
   
   String course[]=new String[5];
   
    String marksArray[]=new String[5];
 
  String az[]=new String[1000];
	String bz[]=new String[1000];
	String cz[]=new String[1000];
	String dz[]=new String[1000];
	String ez[]=new String[1000];
	String fz[]=new String[1000];
	String gz[]=new String[1000];
	String hz[]=new String[1000];
	String iz[]=new String[1000];
	String jz[]=new String[1000];
	String kz[]=new String[1000];
	String lz[]=new String[1000];
	String mz[]=new String[1000]; 

  int I=0,J=0;















 base.cls();   base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,50); base.b(); System.out.print(sh+"'s MARK SHEET ");  base.o();
 base.gotoxy(4,43);base.b(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  base.gotoxy(5,0);
	     { 

         
        String fileName = "tablem.txt";

        
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("                  "+line);
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
    }
	
	
	 
	
	  
	
	
	try{
		File x=new File("studentsandcourses.txt");
	
	Scanner mx=new Scanner(x);
	
	while(mx.hasNextLine())
	{
		az[I]=mx.nextLine();
		bz[I]=mx.nextLine();
		cz[I]=mx.nextLine();
		 dz[I]=mx.nextLine();
		ez[I]=mx.nextLine();
		 fz[I]=mx.nextLine();
		gz[I]=mx.nextLine();
		 hz[I]=mx.nextLine();
		iz[I]=mx.nextLine();
		 jz[I]=mx.nextLine();
		kz[I]=mx.nextLine();
		 lz[I]=mx.nextLine();
		mz[I]=mx.nextLine();
		
		I++;
		
		
		
	} mx.close(); }
	
	catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
									   
			while(J<I)
			{
				if(az[J].equals(sh))
				{
					
					 course[0]=dz[J];
         					
					 course[1]=fz[J];
					 course[2]=hz[J];
					 course[3]=jz[J];
					 course[4]=lz[J];
					
					
					
				 marksArray[0]=ez[J];
				 marksArray[1]=gz[J];
					 marksArray[2]=iz[J];
					 marksArray[3]=kz[J];
					 marksArray[4]=mz[J];
					
					break;
					
				}
				
				
			 
				
				
				
				J++;
			}
	
	
	     
	
	     c1q1=cut( marksArray[0], 1, 3);
		 c1q2=cut( marksArray[0], 5, 7);
		 c1q3=cut( marksArray[0], 9, 11);
		 c1ap=cut( marksArray[0], 13, 15);
		 c1as=cut( marksArray[0], 17, 19);
		
		
		 c2q1=cut( marksArray[1], 1, 3);
		 c2q2=cut( marksArray[1], 5, 7);
		 c2q3=cut( marksArray[1], 9, 11);
		 c2ap=cut( marksArray[1], 13, 15);
		 c2as=cut( marksArray[1], 17, 19);
	
	
	
		 c3q1=cut( marksArray[2], 1, 3);
		 c3q2=cut( marksArray[2], 5, 7);
		 c3q3=cut( marksArray[2], 9, 11);
		 c3ap=cut( marksArray[2], 13, 15);
		 c3as=cut( marksArray[2], 17, 19);
	
	
	
		 c4q1=cut( marksArray[3], 1, 3);
		 c4q2=cut( marksArray[3], 5, 7);
		  c4q3=cut( marksArray[3], 9, 11);
		 c4ap=cut( marksArray[3], 13, 15);
		 c4as=cut( marksArray[3], 17, 19);
	
	
		 c5q1=cut( marksArray[4], 1, 3);
		 c5q2=cut( marksArray[4], 5, 7);
		 c5q3=cut( marksArray[4], 9, 11);
		 c5ap=cut( marksArray[4], 13, 15);
		 c5as=cut( marksArray[4], 17, 19);
	
	     c1tm= c1q1+ c1q2+ c1q3+ c1ap+ c1as;
		
		 c2tm= c2q1+ c2q2+ c2q3+ c2ap+ c2as;
		 
		  c3tm= c3q1+ c3q2+ c3q3+ c3ap+ c3as;
		  
		    c4tm= c4q1+ c4q2+ c4q3+ c4ap+ c4as;
		   
		   c5tm= c5q1+ c5q2+ c5q3+ c5ap+ c5as;
			
		 
			
			try {File sx=new File("allstudentgrades.txt");
	Scanner m2=new Scanner(sx);
	
	while(m2.hasNextLine())
	{
		
		aq=m2.nextLine();
		bq=m2.nextLine();
		 
		if(aq.equalsIgnoreCase(sh)){break;}
	 
	}}
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}
	 
			
		boolean graded=false;	 
			 
			
			
			
			
			
			 if(bq.equalsIgnoreCase("Not Graded")) 
			 {  grade1="";
                 grade2="";
					grade3="";
						grade4="";
							grade5=""; 
			   }
			   
			   
			else
			{  grade1=grader( c1tm);
			   grade2=grader( c2tm);
			    grade3=grader( c3tm);
				 grade4=grader( c4tm);
			 grade5=grader( c5tm); }
			
			 
	if(bq.equals("Not Graded")){graded=false;}		 
	else{graded=true;}	
	
	
if(bq!="Not Graded")
{ if(grade1.equals("F") || grade2.equals("F") || grade3.equals("F")  || grade4.equals("F") || grade5.equals("F") )
 {
	 
	  CGPA=0.0f;
	 
	 
 }
 else
 {
	CGPA=Float.parseFloat(bq);	   
	 
	 
	 
}}
 
CGPA=Float.parseFloat(bq);	
	
	base.gotoxy(9,20); base.g(); System.out.print(course[0]); base.o();
	
	base.gotoxy(12,20); base.g(); System.out.print(course[1]); base.o();
	
	base.gotoxy(15,20); base.g(); System.out.print(course[2]); base.o();
	
	base.gotoxy(18,20); base.g(); System.out.print(course[3]); base.o();
	
	base.gotoxy(21,20); base.g(); System.out.print(course[4]); base.o();
	
	
	base.gotoxy(9,47); base.r(); System.out.print(c1q1); base.o();
	base.gotoxy(9,57); base.g(); System.out.print(c1q2); base.o();
	base.gotoxy(9,67); base.r(); System.out.print(c1q3); base.o();
	base.gotoxy(9,77); base.g(); System.out.print(c1ap); base.o();
	base.gotoxy(9,91); base.r(); System.out.print(c1as); base.o();
	base.gotoxy(9,103); base.g(); System.out.print(c1tm); base.o();
	base.gotoxy(9,114); base.r(); System.out.print(grade1); base.o();	
	
	base.gotoxy(12,47); base.r(); System.out.print(c2q1); base.o();
	base.gotoxy(12,57); base.g(); System.out.print(c2q2); base.o();
	base.gotoxy(12,67); base.r(); System.out.print(c2q3); base.o();
	base.gotoxy(12,77); base.g(); System.out.print(c2ap); base.o();
	base.gotoxy(12,91); base.r(); System.out.print(c2as); base.o();
	base.gotoxy(12,103); base.g(); System.out.print(c2tm); base.o();	
	base.gotoxy(12,114); base.r(); System.out.print(grade2); base.o();
	
	base.gotoxy(15,47); base.r(); System.out.print(c3q1); base.o();
	base.gotoxy(15,57); base.g(); System.out.print(c3q2); base.o();
	base.gotoxy(15,67); base.r(); System.out.print(c3q3); base.o();
	base.gotoxy(15,77); base.g(); System.out.print(c3ap); base.o();
	base.gotoxy(15,91); base.r(); System.out.print(c3as); base.o();
	base.gotoxy(15,103); base.g();  System.out.print(c3tm); base.o();
	base.gotoxy(15,114); base.r(); System.out.print(grade3); base.o();	
	
	base.gotoxy(18,47); base.r(); System.out.print(c4q1); base.o();
	base.gotoxy(18,57); base.g(); System.out.print(c4q2); base.o();
	base.gotoxy(18,67); base.r(); System.out.print(c4q3); base.o();
	base.gotoxy(18,77); base.g(); System.out.print(c4ap); base.o();
	base.gotoxy(18,91); base.r(); System.out.print(c4as); base.o();
	base.gotoxy(18,103); base.g(); System.out.print(c4tm); base.o();
	base.gotoxy(18,114); base.r(); System.out.print(grade4); base.o();
	
	base.gotoxy(21,47); base.r(); System.out.print(c5q1); base.o();
	base.gotoxy(21,57); base.g(); System.out.print(c5q2); base.o();
	base.gotoxy(21,67); base.r(); System.out.print(c5q3); base.o();
	base.gotoxy(21,77); base.g(); System.out.print(c5ap); base.o();
	base.gotoxy(21,91); base.r(); System.out.print(c5as); base.o();
	base.gotoxy(21,103); base.g(); System.out.print(c5tm); base.o();
	base.gotoxy(21,114); base.r(); System.out.print(grade5); base.o();
	
	
	
	
	 
	
	
	 
	
	
	
	
	
	 
	
	
	if(graded==true){ base.gotoxy(24,55);  System.out.print(sh+"'s CGPA : "+CGPA);}
	base.gotoxy(26,53);	base.g(); System.out.print("Enter Any Key to Return :  "); base.o();  String gt=s.nextLine();   this.tmenu();
	 
  
 }

   	
	
	void addMarks()
	{
		 Scanner s=new Scanner(System.in);
		 String ax[]=new String[1000];
		 	 String bx[]=new String[1000]; int i=0,j=0;
		
		int a,b,c;   
	base.cls(); base.boxmaker();
  base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,57); base.g(); System.out.print("Student Grades: ");  base.o();
 base.gotoxy(4,43);base.b(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");   
 
 
 	try{   File myFilex=new File("allstudentgrades.txt");
					   Scanner m1=new Scanner(myFilex); System.out.println();
					   while(m1.hasNextLine())
					   {  
				            
						 
				           ax[i]=m1.nextLine(); base.gotoxy(11+2*i,50);   System.out.print(i+1+".  "+ax[i]+" ----- CGPA : ");  
						   bx[i]=m1.nextLine(); if(bx[i].equals("Not Graded") || bx[i].equals("0.0")){base.r(); System.out.println(bx[i]); base.o();}
						   else{ base.g(); System.out.println(bx[i]); base.o();}
						    
                                System.out.println();
						   i++;
				         
					   }
					   m1.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
			 	 int p=0;
			 
			 
			 
			 base.gotoxy(6,53); System.out.print("Choose Student to add marks (0 to return) : "); 
			 try{ p=s.nextInt();} 
               catch(InputMismatchException e)
	         {  base.r();  base.gotoxy(7,53); System.out.print("Invalid input, Try again"); base.o(); base.sleep(3000); this.addMarks(); }		

             if(p>i || p<0)  {  base.r();  base.gotoxy(7,53); System.out.print("Invalid input, Try again"); base.o(); base.sleep(3000); this.addMarks(); }					 
			 
			 
			 if(p==0){this.tmenu();}
			 
			 p=p-1;

			 if(bx[p].equalsIgnoreCase("Not Graded"))
			 {
				  base.gotoxy(8,53); base.g(); System.out.print("You have selected "+ax[p] ); base.y(); base.sleep(1500); 
			 this.addMarks2(ax[p]);}
				 
			 
			 
			        
	else{  base.gotoxy(8,53); base.g(); System.out.print("You have selected "+ax[p] ); base.o(); base.sleep(1500); this.addMarks2(ax[p]); }}
		 
		
		
		void addMarks2(String ss)
		{
			base.cls();  int I=0, J=0; 
		 
			
			String course[]=new String[5];
			String marksArray[]=new String[5];
  base.gotoxy(2,43); base.y(); System.out.print(":::::::::::::::::::::::::::::::::::::::::"); base.o(); 
 base.gotoxy(3,49); base.r(); System.out.print("Adding Marks of "+ss);  base.o();                  
 base.gotoxy(3,99);  base.r(); System.out.print("Enter 999 to return");  base.o(); 
 base.gotoxy(4,43);base.y();   System.out.print(":::::::::::::::::::::::::::::::::::::::::"); base.o();
			System.out.println();
			
	String az[]=new String[1000];
	String bz[]=new String[1000];
	String cz[]=new String[1000];
	String dz[]=new String[1000];
	String ez[]=new String[1000];
	String fz[]=new String[1000];
	String gz[]=new String[1000];
	String hz[]=new String[1000];
	String iz[]=new String[1000];
	String jz[]=new String[1000];
	String kz[]=new String[1000];
	String lz[]=new String[1000];
	String mz[]=new String[1000]; 
			
	String aq[]=new String[1000];		
	String bq[]=new String[1000];
			
		base.o();	
        // The name of the file to open.
        String fileName = "tablem.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
               System.out.println("              "+line);  
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
			
		
	
	base.o();
	 
	 	
		
		
	try{
		File x=new File("studentsandcourses.txt");
	
	Scanner mx=new Scanner(x);
	
	while(mx.hasNextLine())
	{
		az[I]=mx.nextLine();
		bz[I]=mx.nextLine();
		cz[I]=mx.nextLine();
		 dz[I]=mx.nextLine();
		ez[I]=mx.nextLine();
		 fz[I]=mx.nextLine();
		gz[I]=mx.nextLine();
		 hz[I]=mx.nextLine();
		iz[I]=mx.nextLine();
		 jz[I]=mx.nextLine();
		kz[I]=mx.nextLine();
		 lz[I]=mx.nextLine();
		mz[I]=mx.nextLine();
		
		I++;
		
		
		
	} mx.close(); }
	
	catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
									   
			while(J<I)
			{
				if(az[J].equals(ss)   )
				{
					
					course[0]=dz[J];
         					
					 course[1]=fz[J];
					 course[2]=hz[J];
					 course[3]=jz[J];
					 course[4]=lz[J];
					
					
					
					 marksArray[0]=ez[J];
					 marksArray[1]=gz[J];
					 marksArray[2]=iz[J];
					 marksArray[3]=kz[J];
					 marksArray[4]=mz[J];
					
					break;
					
				}
				
				
			 
				
				
				
				J++;
			}
	
	
	      
			int tq=0;
		 
			
			try {File sx=new File("allstudentgrades.txt");
	Scanner m2=new Scanner(sx);
	
	while(m2.hasNextLine())
	{
		
		aq[tq]=m2.nextLine();
		bq[tq]=m2.nextLine();  
		 
		if(aq[tq].equalsIgnoreCase(ss)){break;} 
		tq++;
	 
	}}
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						} 
		
		 
		
	base.gotoxy(9,16); base.g(); System.out.print(course[0]); base.o();
	
	base.gotoxy(12,16); base.g(); System.out.print(course[1]); base.o();
	
	base.gotoxy(15,16); base.g(); System.out.print(course[2]); base.o();
	
	base.gotoxy(18,16); base.g(); System.out.print(course[3]); base.o();
	
	base.gotoxy(21,16); base.g(); System.out.print(course[4]); base.o();	
		
		
	int qwt=0;	
	int i=0, j=42, k=0;
	int sum=0;
	int qs[]=new int[5];
	String grades[]=new String[1000];
	
	String marksArray2[]=new String[5];
	

  for(i=0; i<=4; i++)
  {
	  
	  k=0; int vb=0;
	  
	 for(j=42; j<=82; j++)
	 {
		 base.gotoxy(9+3*i,j-1); 


           if(vb==4){ base.gotoxy(9+3*i,j+5);    }




		 try{qwt=s.nextInt(); vb++;}
		 
		  catch(InputMismatchException e)
	 {  base.r(); base.gotoxy(26,43);  System.out.print("Invalid input, Try again"); base.o(); base.sleep(3500); this.tmenu(); break; }
	 
	 if(qwt>20 || qwt<0) {  base.r(); base.gotoxy(26,43);  System.out.print("Marks cannot exceed 20, Try again"); base.o(); base.sleep(3500); this.tmenu(); break; }
		 
		  

		else  if(qwt>=999){ base.cls(); this.tmenu(); break; } qs[k]=qwt; k++; j=j+9; 
		 if(j>=82){  base.gotoxy(9+3*i,j+10); base.g(); System.out.print(qs[0]+qs[1]+qs[2]+qs[3]+qs[4]);  base.o();
		 
		 sum=sum+qs[0]+qs[1]+qs[2]+qs[3]+qs[4];

     base.gotoxy(9+3*i,j+19);  base.g(); System.out.print(grader(qs[0]+qs[1]+qs[2]+qs[3]+qs[4]));  base.o();
	 
	 grades[i]=grader(qs[0]+qs[1]+qs[2]+qs[3]+qs[4]);
	 
         marksArray2[i]=tripler(qs[0],qs[1],qs[2],qs[3],qs[4]);
      		 break;}
		 
		 
		 
		 
	 }		 
	  
	  
	  
	  
  }	  
  
  
  float cgpa=(sum*4)/450;
  
  if(cgpa>4f){cgpa=4f;}
 else if(grades[0].equals("F") || grades[1].equals("F") || grades[2].equals("F") || grades[3].equals("F") || grades[4].equals("F"))
 {
	 
	 cgpa=0.0f;
	 
 }
  
  
  J=0;
  
  while(J<I)
			{
				if(az[J].equals(ss)   )
				{
					 
					
					
					
					 
					 
					 
					 ez[J]=marksArray2[0];
					 gz[J]=marksArray2[1];
					 iz[J]=marksArray2[2];
					 kz[J]=marksArray2[3];
					 mz[J]=marksArray2[4];
					
					break;
					
				}
				
				
			 
				
				
				
				J++;
			} 
		
		J=0;
		
		
		try{
														// Create file 
											FileWriter fstream = new FileWriter("studentsandcourses.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											 while(J<=I && az[J]!=null)
											 {
												out.write(az[J]+"\n"); 
												out.write(bz[J]+"\n") ;
												out.write(cz[J]+"\n") ;
												out.write(dz[J]+"\n"); 
												out.write(ez[J]+"\n"); 
												out.write(fz[J]+"\n"); 
												out.write(gz[J]+"\n"); 
												out.write(hz[J]+"\n"); 
												out.write(iz[J]+"\n"); 
												out.write(jz[J]+"\n"); 
												out.write(kz[J]+"\n"); 
												out.write(lz[J]+"\n") ;
												out.write(mz[J]+"\n"); 
												 
												 
												 
												 J++;
												 
											 }
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}
																						
																						
																						
			J=0; I=0;		

   

String al[]=new String[1000];
float bl[]=new float[1000];

String sd=new String();


try{
		File x=new File("allstudentgrades.txt");
	
	Scanner mx=new Scanner(x);
	
	while(mx.hasNextLine())
	{
		al[I]=mx.nextLine();
		sd=mx.nextLine();
		
		if(sd.equals("Not Graded"))
		
		{bl[I]=0.0f;}
		
		else
		
		{bl[I]=Float.parseFloat(sd);}
		 
		
		I++;
		
		
		
	} mx.close(); }
	
	catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }


     J=0;
	 
	 float mxt=cgpa;
	 float cgpa2=0.0f;
	 
	 while(J<=I)
	 {
		if(ss.equals(al[J]) || ss==al[J])
        {
			if(bl[J]==0.0f && cgpa!=0.0f) { mxt=cgpa; bl[J]=mxt;   if(bl[J]>=4.0f){bl[J]=4.0f;} else if(bl[J]<=2.25f){bl[J]=0.0f;} cgpa2=bl[J]; }
			
               else if(bl[J]==0.0f && cgpa==0.0f) {bl[J]=0.0f;    }
			
			else if(cgpa!=0.0f && bl[J]!=0.0f)
			{  mxt=(mxt+cgpa+bl[J])/3f+0.1f; bl[J]=mxt;  if(bl[J]>=4.0f){bl[J]=4.0f;}  else if(bl[J]<=2.25f){bl[J]=0.0f;} cgpa2=bl[J]; }
			
			 
			
			
			 
			
		}			
		 
		 
		 
		 J++;
	 }

									   
		J=0;																				
																						
	try{
														// Create file 
											FileWriter fstream = new FileWriter("allstudentgrades.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											 while(J<=I && al[J]!=null)
											 {
												out.write(al[J]+"\n"); 
												out.write(bl[J]+"\n") ;
												 
												 
												 
												 
												 J++;
												 
											 }
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}		

I=0; J=0;

String wq[]=new String[1000];
		String wq2[]=new String[1000];	




try {File sx=new File("rswitch.txt");
	Scanner m3=new Scanner(sx);
	
	while(m3.hasNextLine())
	{
		
		wq[I]=m3.nextLine();
		wq2[I]=m3.nextLine();
		 
		 I++;
	 
	}m3.close();}  
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
			  	}




    while(J<=I && wq[J]!=null)
	{
		if(wq[J].equals(ss))
		{
			
		  wq2[J]="1";	
			
			
			
		}
		
		
		J++;
		
	}

J=0;

try{
														// Create file 
											FileWriter fstream = new FileWriter("rswitch.txt");
											BufferedWriter out = new BufferedWriter(fstream);
											 while(J<=I && wq[J]!=null)
											 {
												out.write(wq[J]+"\n"); 
												out.write(wq2[J]+"\n") ;
												 
												 
												 
												 
												 J++;
												 
											 }
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}	






																						
    base.gotoxy(28,53); base.g(); System.out.print("Grades of "+ss+" has been added, CGPA( "+cgpa2+" )"); base.y(); 
	
	base.gotoxy(29,53); base.o();System.out.print("Press Any Key to Return : "); String v=s.nextLine(); v=s.nextLine();
	
	base.sleep(1000); 
			 this.tmenu();																						
																						
		}}
		
	 
	
	 
	class admin
	{
		void aViewMarks()
	{
		 Scanner s=new Scanner(System.in);
		 String ax[]=new String[1000];
		 	 String bx[]=new String[1000]; int i=0,j=0;
		
		int a,b,c;   
	base.cls(); base.boxmaker();
  base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,57); base.r(); System.out.print("Student Grades: ");  base.o();
 base.gotoxy(4,43);base.b(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::::");   
 
 
 	try{   File myFilex=new File("allstudentgrades.txt");
					   Scanner m1=new Scanner(myFilex); System.out.println();
					   while(m1.hasNextLine())
					   {  
				            
						 
				           ax[i]=m1.nextLine(); base.gotoxy(11+2*i,50);   System.out.print(i+1+".  "+ax[i]+" ----- CGPA : ");  
						   bx[i]=m1.nextLine(); 
						   if(bx[i].equals("Not Graded") || bx[i].equals("0.0") )
						   {base.r(); System.out.println(bx[i]); base.o();}
						   else{ base.g(); System.out.println(bx[i]); base.o();}
						    
                                System.out.println();
						   i++;
				         
					   }
					   m1.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
			 	 
			 
			 
			 int p=0;
			 base.gotoxy(6,53); System.out.print("Choose Student to view marks (0 to return) : "); 
			 
			 try{p=s.nextInt();}
               catch(InputMismatchException e)
	            { base.gotoxy(7,53); base.r(); System.out.print("Invalid input, Try again"); base.o(); base.sleep(3000); this.amenu();}			 
			 
			 
			 
			 
			 
			 if(p==0){this.amenu();}
			 
			  else if(p>i || p<0){  base.gotoxy(7,53); base.r(); System.out.print("Choose a maximum value of "+i);  base.o(); base.sleep(3000);   this.aViewMarks();}
			  
			    else if(i==0){ base.gotoxy(7,53); base.r(); System.out.print("No students have been added "); base.o(); base.sleep(3000);    this.amenu();}
			 
			 p=p-1;  
			 
			 if(bx[p].equals("Not Graded"))
			  {base.gotoxy(8,53); base.r(); System.out.print("His/Her marks haven't been added yet" ); base.o(); base.sleep(2000); 
			 this.amenu();}
			 
			 else
			 {base.gotoxy(8,53); base.g(); System.out.print("You have selected "+ax[p] ); base.o(); base.sleep(1500); 
			 this.aViewMarks2(ax[p]);}
			 
			 
		 }


  void aViewMarks2( String sh)
  { 
 	String aq=new String();
			String bq=new String(); int u=0;
 
  
 
 float CGPA;
   
   int c1q1;
    int c1q2;
	 int c1q3;
	  int c1ap;
	   int c1as;
	   int c1tm;
	   
	   
	    int c2q1;
    int c2q2;
	 int c2q3;
	  int c2ap;
	   int c2as;
	    int c2tm;
	   
	    int c3q1;
    int c3q2;
	 int c3q3;
	  int c3ap;
	   int c3as;
	    int c3tm;
	   
	    int c4q1;
    int c4q2;
	 int c4q3;
	  int c4ap;
	   int c4as;
	    int c4tm;
		
		
	    int c5q1;
    int c5q2;
	 int c5q3;
	  int c5ap;
	   int c5as;
	    int c5tm;
		
   String grade1=new String();
    String grade2=new String();
	 String grade3=new String();
	  String grade4=new String();
	   String grade5=new String();
   
   
   String course[]=new String[5];
   
    String marksArray[]=new String[5];
 
  String az[]=new String[1000];
	String bz[]=new String[1000];
	String cz[]=new String[1000];
	String dz[]=new String[1000];
	String ez[]=new String[1000];
	String fz[]=new String[1000];
	String gz[]=new String[1000];
	String hz[]=new String[1000];
	String iz[]=new String[1000];
	String jz[]=new String[1000];
	String kz[]=new String[1000];
	String lz[]=new String[1000];
	String mz[]=new String[1000]; 

  int I=0,J=0;















 base.cls();   base.gotoxy(2,43); System.out.print("::::::::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,50); base.b(); System.out.print(sh+"'s MARK SHEET ");  base.o();
 base.gotoxy(4,43);base.b(); base.o(); System.out.print("::::::::::::::::::::::::::::::::::::::::::::::");  base.gotoxy(5,0);
	     { 

         
        String fileName = "tablem.txt";

        
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("                  "+line);
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
    }
	
	
	 
	
	  
	
	
	try{
		File x=new File("studentsandcourses.txt");
	
	Scanner mx=new Scanner(x);
	
	while(mx.hasNextLine())
	{
		az[I]=mx.nextLine();
		bz[I]=mx.nextLine();
		cz[I]=mx.nextLine();
		 dz[I]=mx.nextLine();
		ez[I]=mx.nextLine();
		 fz[I]=mx.nextLine();
		gz[I]=mx.nextLine();
		 hz[I]=mx.nextLine();
		iz[I]=mx.nextLine();
		 jz[I]=mx.nextLine();
		kz[I]=mx.nextLine();
		 lz[I]=mx.nextLine();
		mz[I]=mx.nextLine();
		
		I++;
		
		
		
	} mx.close(); }
	
	catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
									   
			while(J<I)
			{
				if(az[J].equals(sh))
				{
					
					 course[0]=dz[J];
         					
					 course[1]=fz[J];
					 course[2]=hz[J];
					 course[3]=jz[J];
					 course[4]=lz[J];
					
					
					
				 marksArray[0]=ez[J];
				 marksArray[1]=gz[J];
					 marksArray[2]=iz[J];
					 marksArray[3]=kz[J];
					 marksArray[4]=mz[J];
					
					break;
					
				}
				
				
			 
				
				
				
				J++;
			}
	
	
	     
	
	     c1q1=cut( marksArray[0], 1, 3);
		 c1q2=cut( marksArray[0], 5, 7);
		 c1q3=cut( marksArray[0], 9, 11);
		 c1ap=cut( marksArray[0], 13, 15);
		 c1as=cut( marksArray[0], 17, 19);
		
		
		 c2q1=cut( marksArray[1], 1, 3);
		 c2q2=cut( marksArray[1], 5, 7);
		 c2q3=cut( marksArray[1], 9, 11);
		 c2ap=cut( marksArray[1], 13, 15);
		 c2as=cut( marksArray[1], 17, 19);
	
	
	
		 c3q1=cut( marksArray[2], 1, 3);
		 c3q2=cut( marksArray[2], 5, 7);
		 c3q3=cut( marksArray[2], 9, 11);
		 c3ap=cut( marksArray[2], 13, 15);
		 c3as=cut( marksArray[2], 17, 19);
	
	
	
		 c4q1=cut( marksArray[3], 1, 3);
		 c4q2=cut( marksArray[3], 5, 7);
		  c4q3=cut( marksArray[3], 9, 11);
		 c4ap=cut( marksArray[3], 13, 15);
		 c4as=cut( marksArray[3], 17, 19);
	
	
		 c5q1=cut( marksArray[4], 1, 3);
		 c5q2=cut( marksArray[4], 5, 7);
		 c5q3=cut( marksArray[4], 9, 11);
		 c5ap=cut( marksArray[4], 13, 15);
		 c5as=cut( marksArray[4], 17, 19);
	
	     c1tm= c1q1+ c1q2+ c1q3+ c1ap+ c1as;
		
		 c2tm= c2q1+ c2q2+ c2q3+ c2ap+ c2as;
		 
		  c3tm= c3q1+ c3q2+ c3q3+ c3ap+ c3as;
		  
		    c4tm= c4q1+ c4q2+ c4q3+ c4ap+ c4as;
		   
		   c5tm= c5q1+ c5q2+ c5q3+ c5ap+ c5as;
			
		 
			
			try {File sx=new File("allstudentgrades.txt");
	Scanner m2=new Scanner(sx);
	
	while(m2.hasNextLine())
	{
		
		aq=m2.nextLine();
		bq=m2.nextLine();
		 
		if(aq.equalsIgnoreCase(sh)){break;}
	 
	}}
	catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}
	 
			
		boolean graded=false;	 
			 
			
			
			
			
			
			 if(bq.equalsIgnoreCase("Not Graded")) 
			 {  grade1="";
                 grade2="";
					grade3="";
						grade4="";
							grade5=""; 
			   }
			   
			   
			else
			{  grade1=grader( c1tm);
			   grade2=grader( c2tm);
			    grade3=grader( c3tm);
				 grade4=grader( c4tm);
			 grade5=grader( c5tm); }
			
			 
	if(bq.equals("Not Graded")){graded=false;}		 
	else{graded=true;}	
	
	
if(bq!="Not Graded")
{ if(grade1.equals("F") || grade2.equals("F") || grade3.equals("F")  || grade4.equals("F") || grade5.equals("F") )
 {
	 
	  CGPA=0.0f;
	 
	 
 }
 else
 {
	CGPA=Float.parseFloat(bq);	   
	 
	 
	 
}}
 
CGPA=Float.parseFloat(bq);	
	
	base.gotoxy(9,20); base.g(); System.out.print(course[0]); base.o();
	
	base.gotoxy(12,20); base.g(); System.out.print(course[1]); base.o();
	
	base.gotoxy(15,20); base.g(); System.out.print(course[2]); base.o();
	
	base.gotoxy(18,20); base.g(); System.out.print(course[3]); base.o();
	
	base.gotoxy(21,20); base.g(); System.out.print(course[4]); base.o();
	
	
	base.gotoxy(9,47); base.r(); System.out.print(c1q1); base.o();
	base.gotoxy(9,57); base.g(); System.out.print(c1q2); base.o();
	base.gotoxy(9,67); base.r(); System.out.print(c1q3); base.o();
	base.gotoxy(9,77); base.g(); System.out.print(c1ap); base.o();
	base.gotoxy(9,91); base.r(); System.out.print(c1as); base.o();
	base.gotoxy(9,103); base.g(); System.out.print(c1tm); base.o();
	base.gotoxy(9,114); base.r(); System.out.print(grade1); base.o();	
	
	base.gotoxy(12,47); base.r(); System.out.print(c2q1); base.o();
	base.gotoxy(12,57); base.g(); System.out.print(c2q2); base.o();
	base.gotoxy(12,67); base.r(); System.out.print(c2q3); base.o();
	base.gotoxy(12,77); base.g(); System.out.print(c2ap); base.o();
	base.gotoxy(12,91); base.r(); System.out.print(c2as); base.o();
	base.gotoxy(12,103); base.g(); System.out.print(c2tm); base.o();	
	base.gotoxy(12,114); base.r(); System.out.print(grade2); base.o();
	
	base.gotoxy(15,47); base.r(); System.out.print(c3q1); base.o();
	base.gotoxy(15,57); base.g(); System.out.print(c3q2); base.o();
	base.gotoxy(15,67); base.r(); System.out.print(c3q3); base.o();
	base.gotoxy(15,77); base.g(); System.out.print(c3ap); base.o();
	base.gotoxy(15,91); base.r(); System.out.print(c3as); base.o();
	base.gotoxy(15,103); base.g();  System.out.print(c3tm); base.o();
	base.gotoxy(15,114); base.r(); System.out.print(grade3); base.o();	
	
	base.gotoxy(18,47); base.r(); System.out.print(c4q1); base.o();
	base.gotoxy(18,57); base.g(); System.out.print(c4q2); base.o();
	base.gotoxy(18,67); base.r(); System.out.print(c4q3); base.o();
	base.gotoxy(18,77); base.g(); System.out.print(c4ap); base.o();
	base.gotoxy(18,91); base.r(); System.out.print(c4as); base.o();
	base.gotoxy(18,103); base.g(); System.out.print(c4tm); base.o();
	base.gotoxy(18,114); base.r(); System.out.print(grade4); base.o();
	
	base.gotoxy(21,47); base.r(); System.out.print(c5q1); base.o();
	base.gotoxy(21,57); base.g(); System.out.print(c5q2); base.o();
	base.gotoxy(21,67); base.r(); System.out.print(c5q3); base.o();
	base.gotoxy(21,77); base.g(); System.out.print(c5ap); base.o();
	base.gotoxy(21,91); base.r(); System.out.print(c5as); base.o();
	base.gotoxy(21,103); base.g(); System.out.print(c5tm); base.o();
	base.gotoxy(21,114); base.r(); System.out.print(grade5); base.o();
	
	
	
	
	 
	
	
	 
	
	
	
	
	
	 
	
	
	if(graded==true){ base.gotoxy(24,48);  System.out.print(sh+"'s CGPA : "+CGPA);}
	base.gotoxy(26,46);	base.g(); System.out.print("Enter Any Key to Return :  "); base.o(); 
	
	Scanner s=new Scanner(System.in);  String gt=s.nextLine();   this.amenu();
	 
  
 }
		
		
		void amenu()
	{     Scanner s=new Scanner(System.in);
		int b,c; String a=new String();  
	base.cls(); base.boxmaker();
  base.gotoxy(2,43); System.out.print(":::::::::::::::::::::::::::::::::::::::::");  
 base.gotoxy(3,57); base.g(); System.out.print("Admin PORTAL: ");  base.o();
 base.gotoxy(4,43);base.b(); base.o(); System.out.print(":::::::::::::::::::::::::::::::::::::::::");   
 base.gotoxy(7,52); base.g();System.out.print("1. "); base.o();System.out.print("Add Students : ");
 base.gotoxy(10,52); base.g(); System.out.print("2. "); base.o();System.out.print("View Results : "); 
 base.gotoxy(13,52); base.g(); System.out.print("3. "); base.o();System.out.print("Log Out : ");  
 base.gotoxy(18,46);  System.out.print("Choose Any One :  ");  a=s.nextLine();   
 
		if(a.equals("1")){this.addStudents();}
		
		else if(a.equals("3"))
		{ try{	FileWriter f=new FileWriter("loginstatus.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("0");
			bc.close(); }
			catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 }
			
			
			
			
			
			base bb=new base();  bb.menu();}
		
		else if(a.equals("2")){base bb=new base(); this.aViewMarks();}
		
		 else{base.cls(); admin bbc=new admin(); bbc.amenu(); }
 
		
	}
	
	
	 
		
		void addStudents()
	{ String a,b,c,cc; boolean problem=false;
	  Scanner s=new Scanner(System.in);
	
	   String ax[]=new String[1000];
	   String bx[]=new String[1000];
	   String cx[]=new String[1000];
	   
	   int i=0, j=0;
                     		 base.cls();  base.boxmaker();
		  base.gotoxy(2,43); System.out.print("::::::::::::::::::::::::::::::::::");  
           base.gotoxy(3,48);  base.g(); System.out.print("Student Registration: ");   base.o();
           base.gotoxy(4,43); base.b();  base.o(); System.out.print("::::::::::::::::::::::::::::::::::");    base.gotoxy(0,0);  
		  
		   base.gotoxy(7,52);  base.g();System.out.print("1. ");  base.o();System.out.print("Enter His/Her name: ");  base.g(); a=s.nextLine();  base.o();
           base.gotoxy(10,52);  base.g();System.out.print("2. ");  base.o();System.out.print("Enter His/Her new Id: ");  base.g(); b=s.nextLine();  base.o();
		  
		  
           base.gotoxy(13,52);  base.g(); System.out.print("3. ");  base.o();System.out.print("Enter His/Her new Password: ");     c=s.nextLine();
		   base.gotoxy(13,83);  base.g(); for(int mm=0; mm<=c.length(); mm++){System.out.print("*");  base.sleep(40); }  base.g();  base.o();
		 
		   base.sleep(1000); 
		
		
		 
		String dx[]=new String[1000];
		
		
		try{   File myFilex=new File("allstudentsinfo.txt");
					   Scanner m1=new Scanner(myFilex);
					   while(m1.hasNextLine())
					   {  
				         
						 
				           ax[i]=m1.nextLine();
						   bx[i]=m1.nextLine();
						   cx[i]=m1.nextLine();
						    dx[i]=m1.nextLine();
						   i++;
				         
					   }
					   m1.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
				    
					
					for(j=0; j<i && ax[j]!=null && bx[j]!=null && cx[j]!=null; j++ )
					{
						if(ax[j].equalsIgnoreCase(a) || bx[j].equalsIgnoreCase(b) )
						{ problem=true;   break;    }
						
						
					}
					
					if(problem==true)
					{ base.gotoxy(18,52);  base.r();   System.out.print("Name/ID already taken");  base.o();  
						base.sleep(3000); this.amenu();}
						
					
		
		
		
		
		
		
		
		
		else if(problem==false)
		
		{ try{
														// Create file 
											FileWriter fstream = new FileWriter("allstudentsinfo.txt",true);
											BufferedWriter out = new BufferedWriter(fstream);
											 
											out.write(a+"\n");
											out.write(b+"\n");
											out.write(c+"\n");
											out.write(1+"\n");
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}


try{
														// Create file 
											FileWriter fstreamx = new FileWriter("studentsandcourses.txt",true);
											BufferedWriter out = new BufferedWriter(fstreamx);
											 
											out.write(a+"\n");
											out.write(b+"\n");
											out.write(c+"\n");
											out.write("Programming-1"+"\n"); 
											out.write("000-000-000-000-000"+"\n");
									        out.write("Math-1"+"\n");
											out.write("000-000-000-000-000"+"\n");
											
											out.write("English-1"+"\n");
											out.write("000-000-000-000-000"+"\n");
											
											out.write("Physics-1"+"\n");
											out.write("000-000-000-000-000"+"\n");
											out.write("ICS"+"\n");
											out.write("000-000-000-000-000"+"\n");
											
											
											
											 
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}


try{
														// Create file 
											FileWriter fstreamxx = new FileWriter("rswitch.txt",true);
											BufferedWriter out = new BufferedWriter(fstreamxx);
											 
											out.write(a+"\n");
											out.write("0"+"\n");
											 
											 
											
											
											
											 
											 
											//Close the output stream
												out.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}




try{
														// Create file 
											FileWriter fstreamd = new FileWriter("allstudentgrades.txt",true);
											BufferedWriter outq = new BufferedWriter(fstreamd);
											 
											outq.write(a+"\n");
											outq.write("Not Graded"+"\n");
											 
											//Close the output stream
												outq.close();
													}
													catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
																						}



			base.gotoxy(18,52);  base.g();   System.out.print("Student Registration Successful !!");  base.o();
		
	base.sleep(3000); this.amenu();}
	
	else if(problem==true){base.gotoxy(18,52);  base.r();   System.out.print("Name/ID already registered, Try again");  base.o();
		
	base.sleep(3000); this.amenu();} }



public static int cut(String s, int x, int y)
	{
		
		 String ss=s.substring(x-1,y);
		 int xx=Integer.parseInt(ss);
		 
		 return xx;
		
		
	}
	
String grader(int marks)
{ 
if(marks>=90 && marks<=100) {return "A+";}
else if(marks>=85 && marks<=89) {return "A";}
else if(marks>=80 && marks<=84) {return "B+";}
else if(marks>=75 && marks<=79) {return "B";}
else if(marks>=70 && marks<=74) {return "C+";}
else if(marks>=65 && marks<=69) {return "C";}
else if(marks>=60 && marks<=64) {return "D+";}
else if(marks>=50 && marks<=59) {return "D";}
else if(marks<50 ) {return "F";}
	
	
	return "0";
	
	
 }	












	}
		
		
		
	 
		
		
	
	
	
	
	 
 
 
 class base
 {  static Scanner s=new Scanner(System.in);
	 student[] st =new student[100];
	 teacher[] tc =new teacher[100];
	 static int scount=1;
	 static int tcount=1;
	  
	static void animation()
	 {  int i=0;
		while(i<3) { sleep(230); cls();
		 r();
		 {

        // The name of the file to open.
        String fileName = "Welcome.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("                        "+line);  
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
    }
	sleep(200); cls();
	g();
	 
		 {

        // The name of the file to open.
        String fileName = "Welcome.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("                        "+line);  
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
    }
	sleep(200); cls();
	b() ;
		 {

        // The name of the file to open.
        String fileName = "Welcome.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("                        "+line);  
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
	 } 
	 sleep(200); cls();
	o() ;
		 {

        // The name of the file to open.
        String fileName = "Welcome.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("                        "+line);  
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
	 }sleep(300); o(); i++; } 
		 
	 	 sleep(800); String g2; gotoxy(30,50); r(); System.out.print("Press Any Key To Continue : "); o(); g2=s.nextLine();
	 }
	 
	 void login()
	 {     String  cc;
		 cls(); boxmaker(); 
		 String a= new String();
		 String b= new String();
		 boolean loginok=false;
		 
		 
		 gotoxy(2,43); System.out.print("::::::::::::::::::::::::::::::::::");  
          gotoxy(3,53); g(); System.out.print("Log In: ");  o();
          gotoxy(4,43);b(); o(); System.out.print("::::::::::::::::::::::::::::::::::");    
          gotoxy(7,52); g();System.out.print("1. "); o();System.out.print("Enter Id: "); g(); a=s.nextLine(); o();
          gotoxy(10,52); g(); System.out.print("2. "); o();System.out.print("Enter Password: ");     b=s.nextLine();
		  gotoxy(10,71); g(); for(int i=0; i<=b.length(); i++){System.out.print("*"); sleep(40); } g(); o();
		 
		  sleep(1000); 
		
		
		           String ax[]=new String[100];
				   String bx[]=new String[100];
				   String cx[]=new String[100];
				   String dx[]=new String[100];
				
				
				
				
				int i=0,j=0;
				 
				boolean problem=false;
				
				  
				  try{   File myFilex=new File("allstudentsinfo.txt");
					   Scanner m1=new Scanner(myFilex);
					   while(m1.hasNextLine())
					   { 
				         
						 
				           ax[i]=m1.nextLine();
						   bx[i]=m1.nextLine();
						   cx[i]=m1.nextLine();
						   dx[i]=m1.nextLine();
						   i++;
				         
					   }
					   m1.close();
					   
					} 
					catch (FileNotFoundException e) {
                     System.out.println("An error occurred. Your file was not found.");
                        e.printStackTrace();
                                       }
				    
					
					for(j=0; j<i && ax[j]!=null && bx[j]!=null && cx[j]!=null; j++ )
					{
						if(bx[j].equals(a) && cx[j].equals(b) )
						{ loginok=true; 
					
					
					
					
		try{	FileWriter f=new FileWriter("loginstatus.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("1");
			bc.close();
			
			FileWriter ff=new FileWriter("loggedinuserinfo.txt");
			BufferedWriter bcc=new BufferedWriter(ff);
			
			bcc.write(ax[j]+"\n");
			bcc.write(bx[j]+"\n");
			bcc.write(cx[j]+"\n");
			bcc.write(dx[j]+"\n");
		bcc.close();}
		
		catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 }
			 
		 
					
					
					
					 break;    }
						
						
					}
		
		
		if(loginok==true)
		{  gotoxy(13,46); g(); System.out.print("Student Log In Successful !! "); o(); sleep(3000);
			
			
			 
			
			this.gate1(ax[j], bx[j]);
			
			
		}	
	
		
		
		 
	 
	
	else if(a.equals("b")==true && b.equals("2")==true )
		{  gotoxy(13,46); g(); System.out.print("Faculty Log In Successful !! "); o(); 
	 try{	FileWriter f=new FileWriter("loginstatus.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("2");
			bc.close(); }
			catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 }
	
	sleep(3000); this.gate2();}
	
	else if(a.equals("t")==true && b.equals("2")==true )
		{  gotoxy(13,46); g(); System.out.print("Faculty Log In Successful !! "); o(); 
	
	 try{	FileWriter f=new FileWriter("loginstatus.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("2");
			bc.close(); }
			catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 }
	
	sleep(3000); this.gate2();}
	
	
	
	
	
	
	
	
	
	else if(a.equals("a")==true && b.equals("1")==true )
		{  gotoxy(13,46); g(); System.out.print("Admin Log In Successful !! "); o(); 
	
	 try{	FileWriter f=new FileWriter("loginstatus.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("3");
			bc.close(); }
			catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 }
	
	
	sleep(3000); this.gate3();}
	
	
	
	     
		  
	 else{gotoxy(13,46); r(); System.out.print("Unsuccessful Log In, Try Again !! "); o(); sleep(3000); this.menu(); } }
		 
		 
	 
	 
	 
	  void menu(){ String a,b,c;
  cls();	boxmaker();  
  
  
  
   String qf=new String();
try {File de=new File("animationswitch.txt");
Scanner dq=new Scanner(de);

while(dq.hasNextLine())
{
	
  qf=dq.nextLine();
	
	
}
dq.close();
}
catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
		 																			}
  
  
  
  
  
  
  
  
  
  
  
  gotoxy(2,43); System.out.print("::::::::::::::::::::::::::::::::::");  
 gotoxy(3,49);System.out.print("\u001b[32mWelcome to Our Portal: "); System.out.print("\u001b[0m");   
 gotoxy(4,43); System.out.print("::::::::::::::::::::::::::::::::::");   
 gotoxy(7,52); System.out.print("\u001b[32m1. "); System.out.print("\u001b[0mLog In : "); 
 gotoxy(10,52); System.out.print("\u001b[32m2. "); System.out.print("\u001b[0mHow to use this Programme?: ");  
 gotoxy(13,52);System.out.print("\u001b[32m3. "); System.out.print("\u001b[0mAbout Developers : ");  
 if(qf.equals("1")){gotoxy(16,52); g(); System.out.print("4."); o(); System.out.print(" Turn Opening Ainmation "); o(); r(); System.out.print("OFF"); o(); }
 
 else if(qf.equals("0")){gotoxy(16,52); g(); System.out.print("4."); o(); System.out.print(" Turn Opening Ainmation "); o(); g(); System.out.print("ON"); o(); }
 
 gotoxy(21,39); g(); System.out.print("Choose any One : "); o();
 
 
 String d=new String(); d=s.nextLine();  sleep(400); 
 
 
 if(d.equals("1")){  this.login();} 
 
 else if(d.equals("2")){ this.notice();} 
 
  else if(d.equals("3")){ this.about();} 
  
  else if(d.equals("4") && qf.equals("1"))
	  
  {  try{	FileWriter f=new FileWriter("animationswitch.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("0");
			bc.close(); }
			catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 } 
									 this.menu();

	  } 
  
  
  else if(d.equals("4") && qf.equals("0"))
  { try{	FileWriter f=new FileWriter("animationswitch.txt");
			BufferedWriter bc=new BufferedWriter(f);
			
			bc.write("1");
			bc.close(); }
			catch (Exception e){//Catch exception if any
			 System.err.println("Error: " + e.getMessage());
									 }  this.menu();} 
  
  
    else{ cls(); base bb=new base(); bb.menu(); }
 
 }
 
 void notice()
 {  cls();  	 gotoxy(2,43); System.out.print("::::::::::::::::::::::::::::::::::");  
          gotoxy(3,53); r(); System.out.print("INSTRUCTIONS: ");  o();
          gotoxy(4,43);b(); o(); System.out.print("::::::::::::::::::::::::::::::::::"); o();
           System.out.println(); System.out.println();
        // The name of the file to open.
        String fileName = "notice.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("        "+line);
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
		
	r();	System.out.println(); System.out.print("     Enter Any Key To Return  "); String we=s.nextLine();  o(); this.menu();
		
    }
	
	
	void about()
	{  cls();  	 gotoxy(2,47); System.out.print("::::::::::::::::::::::::::::::::::");  
          gotoxy(3,59); b(); System.out.print("ABOUT US: ");  o();
          gotoxy(4,47);b(); o(); System.out.print("::::::::::::::::::::::::::::::::::"); o();
           System.out.println(); System.out.println();
        // The name of the file to open.
        String fileName = "cont.txt";

        // This will reference one line at a time
        String line = null;

        try {
            // FileReader reads text files in the default encoding.
            FileReader fileReader = 
                new FileReader(fileName);

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader = 
                new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                System.out.println("    "+line);
            }   

            // Always close files.
            bufferedReader.close();         
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                "Unable to open file '" + 
                fileName + "'");                
        }
        catch(IOException ex) {
            System.out.println(
                "Error reading file '" 
                + fileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
        }
		
	b();	System.out.println(); System.out.print("     Enter Any Key To Return  "); String we=s.nextLine();   o(); this.menu();
		
    }
	
	
 
 
 void gate1(String a, String b){ st[scount]=new student("Programming 1", "Math 1", "Physics 1", "ICS", "English 1", a, b,"CSE",1);
 
 st[scount].smenu(); scount++;  }
 
 void gate2(){ tc[tcount]=new teacher(); tc[tcount].tmenu();} 
 
  void gate3(){ tc[tcount]=new teacher(); admin az=new admin(); az.amenu();} 

	static void boxmaker()  {  cls();    

             int i=0; int m=0;


               while(m<=0)
                   {

                    while(i<=133-m )
                    {
                        gotoxy(i,0+m);  System.out.print("*");  //sleep(2);
                        gotoxy(i,133-m); System.out.print("*");   //sleep(2);

                         if(i<=133-m) {++i;}


                    }
 gotoxy(0,0); i=0;
                      {   i=0;
                    while(i<=133-m )
                    {
                        gotoxy(0+m,i);     System.out.print("*");  sleep(4);
                        gotoxy(133-m,i); System.out.print("*");  sleep(4);

                         if(i<=133-m) {++i;}


                    } } ++m;  } }
					
					
					
					
					
					
					
					
					
					
					
					
					
					static void boxmaker2()  {  cls();    

             int i=0; int m=0;


               while(m<=0)
                   {

                    while(i<=133-m )
                    {
                        gotoxy(i,0+m);  System.out.print("*");  //sleep(2);
                        gotoxy(i,133-m); System.out.print("*");   //sleep(2);

                         if(i<=133-m) {++i;}


                    }
 gotoxy(0,0); i=0;
                      {   i=0;
                    while(i<=133-m )
                    {
                        gotoxy(0+m,i);     System.out.print("*");  //sleep(4);
                        gotoxy(133-m,i); System.out.print("*");  //sleep(4);

                         if(i<=133-m) {++i;}


                    } } ++m;  } }
 
 
		   
		   
	 static void sleep(int m){try{Thread.sleep(m);}catch(InterruptedException e){System.out.print(e);}}
	 
	 
	 static void cls(){    
	try
	{	
		new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
	}catch(Exception E)
		{
			System.out.println(E);
		}
}   

public static int cut(String s, int x, int y)
	{
		
		 String ss=s.substring(x-1,y);
		 int xx=Integer.parseInt(ss);
		 
		 return xx;
		
		
	}
	
String grader(int marks)
{ 
if(marks>=90 && marks<=100) {return "A+";}
else if(marks>=85 && marks<=89) {return "A";}
else if(marks>=80 && marks<=84) {return "B+";}
else if(marks>=75 && marks<=79) {return "B";}
else if(marks>=70 && marks<=74) {return "C+";}
else if(marks>=65 && marks<=69) {return "C";}
else if(marks>=60 && marks<=64) {return "D+";}
else if(marks>=50 && marks<=59) {return "D";}
else if(marks<50 ) {return "F";}
	
	
	return "0";
	
	
 }	
	
static void gotoxy(int x, int y) { 
char escCode = 0x1B;
int row = x; int column = y;
System.out.print(String.format("%c[%d;%df",escCode,row,column)); // System.out.println("\u001b[32mHello, World!");
 }
 
 
 static void r(){ System.out.print("\u001b[31m"); }
 static void g(){System.out.print("\u001b[32m");}
  static void y(){System.out.print("\u001b[33m");}
   static void b(){System.out.print("\u001b[34m");}
       static void m(){System.out.print("\u001b[35m");}
      static void c(){System.out.print("\u001b[36m");}
 static void o(){System.out.print("\u001b[0m");}
	 
	 public static void main(String[] args)throws Exception 
{  
	
	if(System.getProperty("os.name").startsWith("Windows"))
{
    // Set output mode to handle virtual terminal sequences
    Function GetStdHandleFunc = Function.getFunction("kernel32", "GetStdHandle");
    DWORD STD_OUTPUT_HANDLE = new DWORD(-11);
    HANDLE hOut = (HANDLE)GetStdHandleFunc.invoke(HANDLE.class, new Object[]{STD_OUTPUT_HANDLE});

    DWORDByReference p_dwMode = new DWORDByReference(new DWORD(0));
    Function GetConsoleModeFunc = Function.getFunction("kernel32", "GetConsoleMode");
    GetConsoleModeFunc.invoke(BOOL.class, new Object[]{hOut, p_dwMode});

    int ENABLE_VIRTUAL_TERMINAL_PROCESSING = 4;
    DWORD dwMode = p_dwMode.getValue();
    dwMode.setValue(dwMode.intValue() | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
    Function SetConsoleModeFunc = Function.getFunction("kernel32", "SetConsoleMode");
    SetConsoleModeFunc.invoke(BOOL.class, new Object[]{hOut, dwMode});
}
 
 /////////////////////////////////////////////////////////////////////////////////////
 base b=new base();
 

String qff=new String();
try {File dxe=new File("animationswitch.txt");
Scanner dqq=new Scanner(dxe);

while(dqq.hasNextLine())
{
	
  qff=dqq.nextLine();
	
	
}
dqq.close();
}
catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
		 																			}   

 
 
   if(qff.equals("1")){animation();}
   
   
 String qf=new String();
try {File de=new File("loginstatus.txt");
Scanner dq=new Scanner(de);

while(dq.hasNextLine())
{
	
  qf=dq.nextLine();
	
	
}
dq.close();
}
catch (Exception e){//Catch exception if any
														System.err.println("Error: " + e.getMessage());
		 																			}
teacher ty=new teacher();	
  student sw=new student();
  admin ax=new admin();
  
   if(qf.equals("1")){ sw.smenu();  }
  
  else if(qf.equals("2")){ ty.tmenu();  }
  
    else if(qf.equals("3")){ ax.amenu();  }

  else{b.menu();}
 
 
 
                     
   



 }
	 
	 
	 
	 
 }